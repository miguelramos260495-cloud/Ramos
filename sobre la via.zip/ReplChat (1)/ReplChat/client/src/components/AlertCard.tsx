import { AlertTriangle, Shield, Heart, MapPin, Clock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { Alert } from "@shared/schema";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface AlertCardProps {
  alert: Alert;
  onClick?: () => void;
}

const alertConfig = {
  robbery: {
    icon: AlertTriangle,
    label: "Robo",
    color: "border-emergency",
    bgColor: "bg-emergency/10",
    textColor: "text-emergency",
  },
  legal: {
    icon: Shield,
    label: "Asistencia Legal",
    color: "border-warning",
    bgColor: "bg-warning/10",
    textColor: "text-warning",
  },
  medical: {
    icon: Heart,
    label: "Emergencia Médica",
    color: "border-caution",
    bgColor: "bg-caution/10",
    textColor: "text-caution",
  },
  safe_travel: {
    icon: MapPin,
    label: "Viaje Seguro",
    color: "border-safe",
    bgColor: "bg-safe/10",
    textColor: "text-safe",
  },
};

const statusConfig = {
  active: { label: "Activa", variant: "destructive" as const },
  resolved: { label: "Resuelta", variant: "default" as const },
  cancelled: { label: "Cancelada", variant: "secondary" as const },
};

export function AlertCard({ alert, onClick }: AlertCardProps) {
  const config = alertConfig[alert.type as keyof typeof alertConfig];
  const Icon = config.icon;
  const status = statusConfig[alert.status as keyof typeof statusConfig];

  return (
    <Card
      className={cn(
        "p-4 border-l-4 hover-elevate active-elevate-2 transition-all cursor-pointer",
        config.color
      )}
      onClick={onClick}
      data-testid={`card-alert-${alert.id}`}
    >
      <div className="flex items-start gap-4">
        <div className={cn("p-2 rounded-lg", config.bgColor)}>
          <Icon className={cn("w-10 h-10", config.textColor)} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-semibold text-lg">{config.label}</h3>
            <Badge variant={status.variant} className="shrink-0" data-testid="badge-alert-status">
              {status.label}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mb-2">{alert.location}</p>
          {alert.description && (
            <p className="text-sm mb-3">{alert.description}</p>
          )}
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>
              {format(new Date(alert.createdAt), "dd MMM yyyy, HH:mm", { locale: es })}
            </span>
          </div>
        </div>
      </div>
    </Card>
  );
}
