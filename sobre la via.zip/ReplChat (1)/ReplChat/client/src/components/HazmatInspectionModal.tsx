import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface HazmatInspectionModalProps {
  open: boolean;
  onClose: () => void;
  onComplete: (passed: boolean, notes: string, checklistResults: ChecklistItem[]) => void;
  materialClass?: string;
  materialDescription?: string;
}

interface ChecklistItem {
  id: string;
  label: string;
  checked: boolean;
  critical: boolean; // Si es crítico para aprobar la inspección
}

const INSPECTION_CHECKLIST: ChecklistItem[] = [
  { id: 'placards', label: 'Placas de identificación visibles y legibles', checked: false, critical: true },
  { id: 'containers', label: 'Envases y embalajes en buen estado, sin fugas', checked: false, critical: true },
  { id: 'labels', label: 'Etiquetas de peligro correctamente colocadas', checked: false, critical: true },
  { id: 'securing', label: 'Carga correctamente asegurada y estibada', checked: false, critical: true },
  { id: 'documents', label: 'Hoja de datos de seguridad (SDS) disponible', checked: false, critical: true },
  { id: 'fire_extinguisher', label: 'Extintor en buen estado y accesible', checked: false, critical: true },
  { id: 'spill_kit', label: 'Kit de derrames disponible', checked: false, critical: false },
  { id: 'ventilation', label: 'Ventilación adecuada en área de carga', checked: false, critical: false },
  { id: 'emergency_equipment', label: 'Equipo de emergencia completo', checked: false, critical: true },
  { id: 'vehicle_condition', label: 'Vehículo en condiciones óptimas', checked: false, critical: true },
  { id: 'weight_limits', label: 'Peso dentro de límites permitidos', checked: false, critical: true },
  { id: 'separation', label: 'Materiales incompatibles correctamente separados', checked: false, critical: true },
];

export function HazmatInspectionModal({ 
  open, 
  onClose, 
  onComplete,
  materialClass,
  materialDescription
}: HazmatInspectionModalProps) {
  const [checklist, setChecklist] = useState<ChecklistItem[]>(INSPECTION_CHECKLIST);
  const [notes, setNotes] = useState("");

  const handleCheckItem = (id: string, checked: boolean) => {
    setChecklist(prev => 
      prev.map(item => item.id === id ? { ...item, checked } : item)
    );
  };

  const criticalItemsChecked = checklist
    .filter(item => item.critical)
    .every(item => item.checked);

  const allItemsChecked = checklist.every(item => item.checked);

  const handleComplete = (passed: boolean) => {
    onComplete(passed, notes, checklist);
    // Reset
    setChecklist(INSPECTION_CHECKLIST.map(item => ({ ...item, checked: false })));
    setNotes("");
  };

  const handleClose = () => {
    setChecklist(INSPECTION_CHECKLIST.map(item => ({ ...item, checked: false })));
    setNotes("");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh]" data-testid="hazmat-inspection-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-destructive" />
            Inspección Visual - Material Peligroso
          </DialogTitle>
          <DialogDescription>
            {materialClass && (
              <div className="mt-2 p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                <div className="font-semibold">Clase: {materialClass}</div>
                {materialDescription && (
                  <div className="text-sm mt-1">{materialDescription}</div>
                )}
              </div>
            )}
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[50vh] pr-4">
          <div className="space-y-4 py-4">
            <div className="space-y-3">
              <div className="text-sm font-medium">
                Lista de Verificación Ocular
                <span className="text-muted-foreground ml-2">
                  ({checklist.filter(i => i.checked).length}/{checklist.length})
                </span>
              </div>

              {checklist.map((item) => (
                <div 
                  key={item.id} 
                  className="flex items-start space-x-3 p-3 rounded-lg border hover-elevate"
                  data-testid={`checklist-item-${item.id}`}
                >
                  <Checkbox
                    id={item.id}
                    checked={item.checked}
                    onCheckedChange={(checked) => handleCheckItem(item.id, checked as boolean)}
                    data-testid={`checkbox-${item.id}`}
                  />
                  <div className="flex-1">
                    <Label
                      htmlFor={item.id}
                      className="text-sm font-normal cursor-pointer flex items-center gap-2"
                    >
                      {item.label}
                      {item.critical && (
                        <span className="text-xs bg-destructive/10 text-destructive px-2 py-0.5 rounded">
                          Crítico
                        </span>
                      )}
                    </Label>
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">
                Observaciones de la Inspección
              </label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Registra cualquier anomalía, condición especial o detalle relevante observado durante la inspección..."
                className="resize-none"
                rows={4}
                data-testid="inspection-notes"
              />
            </div>
          </div>
        </ScrollArea>

        <div className="space-y-3 border-t pt-4">
          {/* Estado de la inspección */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
            <div className="flex items-center gap-2">
              {criticalItemsChecked ? (
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              ) : (
                <XCircle className="w-5 h-5 text-destructive" />
              )}
              <span className="text-sm font-medium">
                {criticalItemsChecked 
                  ? "Ítems críticos verificados" 
                  : "Verificar ítems críticos para continuar"}
              </span>
            </div>
            {allItemsChecked && (
              <span className="text-xs text-green-600 font-medium">
                ✓ Inspección completa
              </span>
            )}
          </div>

          {/* Botones de acción */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleClose}
              className="flex-1"
              data-testid="button-cancel-inspection"
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => handleComplete(false)}
              className="flex-1"
              data-testid="button-fail-inspection"
            >
              No Aprobar
            </Button>
            <Button
              onClick={() => handleComplete(true)}
              className="flex-1"
              disabled={!criticalItemsChecked}
              data-testid="button-pass-inspection"
            >
              Aprobar Inspección
            </Button>
          </div>

          <p className="text-xs text-muted-foreground text-center">
            Conforme a la NOM-002-SCT/2011 y NOM-003-SCT/2008
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
