import { useState, useRef } from "react";
import { Mic, MicOff, Video, VideoOff, StopCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface EvidenceRecorderProps {
  onRecordingComplete: (blob: Blob, type: 'audio' | 'video') => void;
  className?: string;
}

export function EvidenceRecorder({ onRecordingComplete, className }: EvidenceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingType, setRecordingType] = useState<'audio' | 'video' | null>(null);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const { toast } = useToast();

  const startRecording = async (type: 'audio' | 'video') => {
    try {
      const constraints = type === 'audio' 
        ? { audio: true }
        : { audio: true, video: { facingMode: 'user' } };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      const mediaRecorder = new window.MediaRecorder(stream, {
        mimeType: type === 'audio' ? 'audio/webm' : 'video/webm'
      });

      chunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { 
          type: type === 'audio' ? 'audio/webm' : 'video/webm' 
        });
        onRecordingComplete(blob, type);
        
        // Clean up
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
          streamRef.current = null;
        }
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start();
      setIsRecording(true);
      setRecordingType(type);
      setRecordingTime(0);

      // Start timer
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

      toast({
        title: type === 'audio' ? 'Grabando audio' : 'Grabando video',
        description: 'La evidencia será adjuntada a la alerta',
      });
    } catch (error) {
      console.error('Error accessing media devices:', error);
      toast({
        title: 'Error',
        description: 'No se pudo acceder al micrófono/cámara',
        variant: 'destructive',
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setRecordingType(null);
      
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }

      toast({
        title: 'Grabación completada',
        description: 'Evidencia guardada correctamente',
      });
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className={`p-4 ${className}`}>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Evidencia</h3>
          {isRecording && (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="text-sm font-mono text-red-500">{formatTime(recordingTime)}</span>
            </div>
          )}
        </div>

        <div className="flex gap-2">
          {!isRecording ? (
            <>
              <Button
                size="sm"
                variant="outline"
                onClick={() => startRecording('audio')}
                className="flex-1"
                data-testid="button-record-audio"
              >
                <Mic className="w-4 h-4 mr-2" />
                Audio
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => startRecording('video')}
                className="flex-1"
                data-testid="button-record-video"
              >
                <Video className="w-4 h-4 mr-2" />
                Video
              </Button>
            </>
          ) : (
            <Button
              size="sm"
              variant="destructive"
              onClick={stopRecording}
              className="w-full"
              data-testid="button-stop-recording"
            >
              <StopCircle className="w-4 h-4 mr-2" />
              Detener {recordingType === 'audio' ? 'Audio' : 'Video'}
            </Button>
          )}
        </div>

        <p className="text-xs text-muted-foreground">
          Graba audio o video como evidencia de la emergencia
        </p>
      </div>
    </Card>
  );
}
