import { useState } from "react";
import { AlertTriangle, Car, Construction, AlertCircle, Shield, X as XIcon, Radio } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { InsertReport } from "@shared/schema";

interface QuickReportButtonProps {
  userLocation: { latitude: number; longitude: number } | null;
}

const reportTypes = [
  {
    type: "accident",
    icon: Car,
    label: "Accidente",
    color: "bg-red-500",
    hoverColor: "hover:bg-red-600",
    severity: "high" as const
  },
  {
    type: "checkpoint",
    icon: Shield,
    label: "Retén/Autoridad",
    color: "bg-blue-500",
    hoverColor: "hover:bg-blue-600",
    severity: "medium" as const
  },
  {
    type: "construction",
    icon: Construction,
    label: "Obra/Construcción",
    color: "bg-yellow-500",
    hoverColor: "hover:bg-yellow-600",
    severity: "medium" as const
  },
  {
    type: "hazard",
    icon: AlertTriangle,
    label: "Peligro en Vía",
    color: "bg-orange-500",
    hoverColor: "hover:bg-orange-600",
    severity: "high" as const
  },
  {
    type: "closure",
    icon: AlertCircle,
    label: "Vía Cerrada",
    color: "bg-purple-500",
    hoverColor: "hover:bg-purple-600",
    severity: "high" as const
  },
  {
    type: "police",
    icon: Shield,
    label: "Patrulla/Radar",
    color: "bg-indigo-500",
    hoverColor: "hover:bg-indigo-600",
    severity: "low" as const
  }
];

export default function QuickReportButton({ userLocation }: QuickReportButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createReportMutation = useMutation({
    mutationFn: async (data: InsertReport) => {
      return await apiRequest("POST", "/api/reports", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      toast({
        title: "¡Reporte enviado!",
        description: "Gracias por ayudar a la comunidad",
      });
      setIsOpen(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo enviar el reporte",
        variant: "destructive",
      });
    },
  });

  const handleQuickReport = async (type: string, severity: "low" | "medium" | "high") => {
    if (!userLocation) {
      toast({
        title: "Ubicación no disponible",
        description: "Espera a que se active el GPS",
        variant: "destructive",
      });
      return;
    }

    const reportData: InsertReport = {
      userId: "", // Se llenará en el backend
      type: type as any,
      latitude: userLocation.latitude,
      longitude: userLocation.longitude,
      location: `${userLocation.latitude.toFixed(6)}, ${userLocation.longitude.toFixed(6)}`,
      severity,
      status: "active",
      expiresAt: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 horas
    };

    createReportMutation.mutate(reportData);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-32 right-6 z-40 flex items-center justify-center w-16 h-16 rounded-full bg-blue-600 hover:bg-blue-700 text-white shadow-lg transition-all hover:scale-110 active:scale-95"
        data-testid="button-quick-report"
        aria-label="Reportes rápidos"
      >
        <Radio className="w-7 h-7" />
      </button>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" onClick={() => setIsOpen(false)}>
      <div className="relative bg-card rounded-2xl p-6 shadow-2xl max-w-md w-full mx-4" onClick={(e) => e.stopPropagation()}>
        <button
          onClick={() => setIsOpen(false)}
          className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
          data-testid="button-close-quick-report"
        >
          <XIcon className="w-6 h-6" />
        </button>

        <h3 className="text-xl font-bold mb-4 text-foreground">Reportar Rápido</h3>
        <p className="text-sm text-muted-foreground mb-6">
          Selecciona el tipo de reporte. Se enviará automáticamente con tu ubicación actual.
        </p>

        <div className="grid grid-cols-2 gap-3">
          {reportTypes.map((report) => {
            const Icon = report.icon;
            return (
              <button
                key={report.type}
                onClick={() => handleQuickReport(report.type, report.severity)}
                disabled={createReportMutation.isPending}
                className={`
                  flex flex-col items-center justify-center gap-2 p-4 rounded-xl
                  ${report.color} ${report.hoverColor}
                  text-white font-medium transition-all
                  hover:scale-105 active:scale-95
                  disabled:opacity-50 disabled:cursor-not-allowed
                `}
                data-testid={`button-report-${report.type}`}
              >
                <Icon className="w-8 h-8" />
                <span className="text-xs text-center leading-tight">{report.label}</span>
              </button>
            );
          })}
        </div>

        {!userLocation && (
          <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
            <p className="text-sm text-yellow-600 dark:text-yellow-400 text-center">
              ⚠️ Esperando ubicación GPS...
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
