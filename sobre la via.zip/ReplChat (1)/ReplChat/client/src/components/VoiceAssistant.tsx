import { useState, useEffect, useRef } from "react";
import { Mic, MicOff, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface VoiceAssistantProps {
  onCommand: (command: string, params?: any) => void;
  className?: string;
}

export function VoiceAssistant({ onCommand, className }: VoiceAssistantProps) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [isSpeaking, setIsSpeaking] = useState(false);
  const recognitionRef = useRef<any>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Check for Web Speech API support
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'es-MX'; // Spanish (Mexico)

      recognition.onresult = (event: any) => {
        let finalTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          }
        }

        if (finalTranscript) {
          setTranscript(finalTranscript);
          processCommand(finalTranscript.toLowerCase());
        }
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        toast({
          title: 'Error de reconocimiento',
          description: 'No se pudo procesar el comando de voz',
          variant: 'destructive',
        });
      };

      recognition.onend = () => {
        if (isListening) {
          recognition.start(); // Restart if still should be listening
        }
      };

      recognitionRef.current = recognition;
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [isListening]);

  const processCommand = (command: string) => {
    const commandMap: { [key: string]: { action: string; params?: any; response: string } } = {
      'emergencia': { action: 'panic', params: { type: 'robbery' }, response: 'Activando alerta de emergencia' },
      'robo': { action: 'panic', params: { type: 'robbery' }, response: 'Activando alerta de robo' },
      'ayuda legal': { action: 'panic', params: { type: 'legal' }, response: 'Solicitando asistencia legal' },
      'asistencia legal': { action: 'panic', params: { type: 'legal' }, response: 'Solicitando asistencia legal' },
      'emergencia médica': { action: 'panic', params: { type: 'medical' }, response: 'Activando emergencia médica' },
      'médica': { action: 'panic', params: { type: 'medical' }, response: 'Activando emergencia médica' },
      'viaje seguro': { action: 'panic', params: { type: 'safe_travel' }, response: 'Activando modo viaje seguro' },
      'centrar mapa': { action: 'center_map', response: 'Centrando mapa en tu ubicación' },
      'centrar ubicación': { action: 'center_map', response: 'Centrando mapa en tu ubicación' },
      'mi ubicación': { action: 'center_map', response: 'Mostrando tu ubicación actual' },
      'acercar': { action: 'zoom_in', response: 'Acercando el mapa' },
      'alejar': { action: 'zoom_out', response: 'Alejando el mapa' },
      'zoom in': { action: 'zoom_in', response: 'Acercando el mapa' },
      'zoom out': { action: 'zoom_out', response: 'Alejando el mapa' },
      'gasolinera cercana': { action: 'find_place', params: { type: 'gas_station' }, response: 'Buscando gasolineras cercanas' },
      'restaurante cercano': { action: 'find_place', params: { type: 'restaurant' }, response: 'Buscando restaurantes cercanos' },
      'hotel cercano': { action: 'find_place', params: { type: 'hotel' }, response: 'Buscando hoteles cercanos' },
    };

    // Find matching command
    for (const [key, value] of Object.entries(commandMap)) {
      if (command.includes(key)) {
        speak(value.response);
        onCommand(value.action, value.params);
        setTranscript('');
        return;
      }
    }

    // If no command matched
    speak('No entendí el comando. Intenta de nuevo.');
  };

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      setIsSpeaking(true);
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'es-MX';
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      
      utterance.onend = () => {
        setIsSpeaking(false);
      };

      window.speechSynthesis.speak(utterance);
    }
  };

  const toggleListening = () => {
    if (!recognitionRef.current) {
      toast({
        title: 'No compatible',
        description: 'Tu navegador no soporta reconocimiento de voz',
        variant: 'destructive',
      });
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
      toast({
        title: 'Asistente activado',
        description: 'Escuchando tus comandos de voz',
      });
    }
  };

  return (
    <Card className={`fixed top-24 left-4 z-40 p-4 bg-card/95 backdrop-blur-sm ${className}`}>
      <div className="flex items-center gap-3">
        <Button
          size="icon"
          variant={isListening ? "destructive" : "default"}
          onClick={toggleListening}
          className="relative"
          data-testid="button-voice-assistant"
        >
          {isListening ? (
            <>
              <MicOff className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
            </>
          ) : (
            <Mic className="w-5 h-5" />
          )}
        </Button>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="text-sm font-semibold">Asistente de Voz</p>
            {isSpeaking && (
              <Volume2 className="w-4 h-4 text-primary animate-pulse" />
            )}
          </div>
          {isListening && transcript && (
            <p className="text-xs text-muted-foreground truncate mt-1">
              {transcript}
            </p>
          )}
          {isListening && !transcript && (
            <p className="text-xs text-muted-foreground mt-1">
              Escuchando...
            </p>
          )}
        </div>
      </div>
      
      {isListening && (
        <div className="mt-3 text-xs text-muted-foreground space-y-1">
          <p className="font-semibold">Comandos disponibles:</p>
          <p>• "Emergencia" / "Robo"</p>
          <p>• "Ayuda legal"</p>
          <p>• "Emergencia médica"</p>
          <p>• "Centrar mapa"</p>
          <p>• "Gasolinera cercana"</p>
        </div>
      )}
    </Card>
  );
}
