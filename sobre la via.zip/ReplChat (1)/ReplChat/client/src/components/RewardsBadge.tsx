import { Trophy, Award, Star, Crown } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface RewardsBadgeProps {
  points: number;
  level: string;
  reportCount: number;
  verifiedReports: number;
  className?: string;
}

export function RewardsBadge({ points, level, reportCount, verifiedReports, className }: RewardsBadgeProps) {
  const levelConfig = {
    bronze: {
      icon: Award,
      color: "from-orange-700 to-orange-800",
      nextLevel: "silver",
      nextPoints: 200,
      bgColor: "bg-orange-500/20",
      textColor: "text-orange-500",
    },
    silver: {
      icon: Star,
      color: "from-gray-400 to-gray-500",
      nextLevel: "gold",
      nextPoints: 500,
      bgColor: "bg-gray-400/20",
      textColor: "text-gray-400",
    },
    gold: {
      icon: Trophy,
      color: "from-yellow-500 to-yellow-600",
      nextLevel: "platinum",
      nextPoints: 1000,
      bgColor: "bg-yellow-500/20",
      textColor: "text-yellow-500",
    },
    platinum: {
      icon: Crown,
      color: "from-purple-500 to-purple-600",
      nextLevel: null,
      nextPoints: null,
      bgColor: "bg-purple-500/20",
      textColor: "text-purple-500",
    },
  };

  const config = levelConfig[level as keyof typeof levelConfig] || levelConfig.bronze;
  const Icon = config.icon;
  const progressToNext = config.nextPoints 
    ? Math.min((points / config.nextPoints) * 100, 100)
    : 100;

  return (
    <Card className={`p-6 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`p-3 rounded-full bg-gradient-to-br ${config.color}`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-lg capitalize">{level}</h3>
            <p className="text-sm text-muted-foreground">{points} puntos</p>
          </div>
        </div>
        <Badge variant="outline" className={config.bgColor + ' ' + config.textColor}>
          Nivel {level}
        </Badge>
      </div>

      {config.nextLevel && (
        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Progreso a {config.nextLevel}</span>
            <span className="font-medium">{points} / {config.nextPoints}</span>
          </div>
          <Progress value={progressToNext} className="h-2" />
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 pt-4 border-t">
        <div className="text-center">
          <p className="text-2xl font-bold" data-testid="text-report-count">{reportCount}</p>
          <p className="text-xs text-muted-foreground">Reportes Creados</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold" data-testid="text-verified-reports">{verifiedReports}</p>
          <p className="text-xs text-muted-foreground">Reportes Verificados</p>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t space-y-2">
        <p className="text-sm font-semibold">Cómo ganar puntos:</p>
        <ul className="text-xs text-muted-foreground space-y-1">
          <li>• Crear reporte vial: +10 puntos</li>
          <li>• Reporte verificado por comunidad: +25 puntos</li>
          <li>• Ayudar a otro conductor: +50 puntos</li>
        </ul>
      </div>
    </Card>
  );
}
