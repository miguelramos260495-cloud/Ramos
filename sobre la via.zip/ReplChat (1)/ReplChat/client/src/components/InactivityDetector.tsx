import { useEffect, useRef, useState } from "react";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface InactivityDetectorProps {
  onInactivityDetected: () => void;
  inactivityThreshold?: number; // milliseconds
  movementThreshold?: number; // meters
  enabled?: boolean;
}

export function InactivityDetector({ 
  onInactivityDetected, 
  inactivityThreshold = 300000, // 5 minutes default
  movementThreshold = 10, // 10 meters default
  enabled = true 
}: InactivityDetectorProps) {
  const [showWarning, setShowWarning] = useState(false);
  const [countdown, setCountdown] = useState(30);
  const lastPositionRef = useRef<{ lat: number; lng: number; timestamp: number } | null>(null);
  const lastMovementRef = useRef<number>(Date.now());
  const inactivityTimerRef = useRef<NodeJS.Timeout | null>(null);
  const countdownTimerRef = useRef<NodeJS.Timeout | null>(null);
  const watchIdRef = useRef<number | null>(null);
  const lastAccelerationRef = useRef<{ x: number; y: number; z: number } | null>(null);

  useEffect(() => {
    if (!enabled) return;

    // Track device movement via DeviceMotion API
    const handleMotion = (event: DeviceMotionEvent) => {
      const acc = event.accelerationIncludingGravity;
      if (!acc || acc.x === null || acc.y === null || acc.z === null) return;

      const current = { x: acc.x, y: acc.y, z: acc.z };

      if (lastAccelerationRef.current) {
        const deltaX = Math.abs(current.x - lastAccelerationRef.current.x);
        const deltaY = Math.abs(current.y - lastAccelerationRef.current.y);
        const deltaZ = Math.abs(current.z - lastAccelerationRef.current.z);
        const totalDelta = deltaX + deltaY + deltaZ;

        // Movement threshold: if acceleration changes by more than 0.5 m/s²
        if (totalDelta > 0.5) {
          lastMovementRef.current = Date.now();
        }
      }

      lastAccelerationRef.current = current;
    };

    // Track device movement via geolocation
    if (navigator.geolocation) {
      watchIdRef.current = navigator.geolocation.watchPosition(
        (position) => {
          const currentPosition = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            timestamp: Date.now()
          };

          if (lastPositionRef.current) {
            const distance = calculateDistance(
              lastPositionRef.current.lat,
              lastPositionRef.current.lng,
              currentPosition.lat,
              currentPosition.lng
            );

            // If significant movement detected
            if (distance > movementThreshold) {
              lastMovementRef.current = Date.now();
            }
          }

          lastPositionRef.current = currentPosition;
        },
        (error) => {
          console.error('Geolocation error:', error);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 5000 }
      );
    }

    // Add devicemotion listener
    window.addEventListener('devicemotion', handleMotion);

    // Check for inactivity
    const checkInactivity = () => {
      const timeSinceLastMovement = Date.now() - lastMovementRef.current;
      
      if (timeSinceLastMovement >= inactivityThreshold) {
        // Show warning dialog
        setShowWarning(true);
        setCountdown(30);
        startCountdown();
      }
    };

    const resetInactivityTimer = () => {
      if (inactivityTimerRef.current) {
        clearInterval(inactivityTimerRef.current);
      }
      inactivityTimerRef.current = setInterval(checkInactivity, 60000); // Check every minute
    };

    resetInactivityTimer();

    return () => {
      window.removeEventListener('devicemotion', handleMotion);
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
      if (inactivityTimerRef.current) {
        clearInterval(inactivityTimerRef.current);
      }
      if (countdownTimerRef.current) {
        clearInterval(countdownTimerRef.current);
      }
    };
  }, [enabled, inactivityThreshold, movementThreshold]);

  const startCountdown = () => {
    countdownTimerRef.current = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          handleInactivityConfirmed();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleInactivityConfirmed = () => {
    if (countdownTimerRef.current) {
      clearInterval(countdownTimerRef.current);
    }
    setShowWarning(false);
    onInactivityDetected();
  };

  const handleUserResponse = () => {
    setShowWarning(false);
    setCountdown(30);
    if (countdownTimerRef.current) {
      clearInterval(countdownTimerRef.current);
    }
    lastMovementRef.current = Date.now();
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // Distance in meters
  };

  if (!enabled) return null;

  return (
    <Dialog open={showWarning} onOpenChange={setShowWarning}>
      <DialogContent className="sm:max-w-md" data-testid="dialog-inactivity-warning">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="p-3 rounded-full bg-gradient-to-br from-yellow-500 to-yellow-600">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <span>Detección de Inactividad</span>
          </DialogTitle>
          <DialogDescription className="text-base pt-2">
            No se ha detectado movimiento en los últimos minutos. 
            ¿Estás bien?
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex flex-col items-center gap-4 py-4">
          <div className="text-center">
            <div className="text-4xl font-bold text-yellow-500 mb-2">{countdown}</div>
            <p className="text-sm text-muted-foreground">
              Se enviará alerta automática en {countdown} segundos
            </p>
          </div>
        </div>
        
        <div className="flex gap-4">
          <Button
            variant="default"
            onClick={handleUserResponse}
            className="flex-1 bg-gradient-to-br from-green-500 to-green-600"
            data-testid="button-im-ok"
          >
            Estoy Bien
          </Button>
          <Button
            variant="destructive"
            onClick={handleInactivityConfirmed}
            className="flex-1"
            data-testid="button-send-alert"
          >
            Enviar Alerta Ahora
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
