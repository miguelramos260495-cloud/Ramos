import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShieldAlert, Mail } from "lucide-react";

const ADMIN_EMAIL = "miguelramos260495@gmail.com";

export function AccessControl({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Verificando acceso...</p>
        </div>
      </div>
    );
  }

  // Solo permitir acceso al administrador
  if (user?.email !== ADMIN_EMAIL) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background p-4">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center gap-6 p-8">
            <ShieldAlert className="w-20 h-20 text-destructive" />
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-bold">Acceso Restringido</h2>
              <p className="text-muted-foreground">
                Esta aplicación es privada y solo está disponible para usuarios autorizados.
              </p>
            </div>
            
            <div className="w-full p-4 rounded-lg bg-muted/50 border">
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-primary mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">¿Necesitas acceso?</p>
                  <p className="text-xs text-muted-foreground">
                    Contacta al administrador para solicitar autorización.
                  </p>
                </div>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={() => window.location.href = "/api/logout"}
              data-testid="button-logout"
            >
              Cerrar Sesión
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
}
