import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RewardsBadge } from "@/components/RewardsBadge";
import MaintenanceReminders from "@/components/MaintenanceReminders";
import InsurancePolicies from "@/components/InsurancePolicies";
import { User, Phone, Mail, Car, Shield } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: emergencyContacts } = useQuery<any[]>({
    queryKey: ["/api/emergency-contacts"],
  });

  const { data: vehicles } = useQuery<any[]>({
    queryKey: ["/api/vehicles"],
  });

  const [contactName, setContactName] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [contactRelationship, setContactRelationship] = useState("");

  const [vehicleType, setVehicleType] = useState("");
  const [vehiclePlate, setVehiclePlate] = useState("");

  const addContactMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/emergency-contacts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
      toast({ title: "Contacto agregado", description: "Contacto de emergencia guardado" });
      setContactName("");
      setContactPhone("");
      setContactRelationship("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo agregar el contacto",
        variant: "destructive",
      });
    },
  });

  const addVehicleMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/vehicles", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
      toast({ title: "Vehículo agregado", description: "Vehículo registrado correctamente" });
      setVehicleType("");
      setVehiclePlate("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo agregar el vehículo",
        variant: "destructive",
      });
    },
  });

  const handleAddContact = () => {
    if (!contactName || !contactPhone) {
      toast({
        title: "Campos requeridos",
        description: "Completa nombre y teléfono",
        variant: "destructive",
      });
      return;
    }
    addContactMutation.mutate({
      name: contactName,
      phone: contactPhone,
      relationship: contactRelationship,
    });
  };

  const handleAddVehicle = () => {
    if (!vehicleType || !vehiclePlate) {
      toast({
        title: "Campos requeridos",
        description: "Completa tipo y placa",
        variant: "destructive",
      });
      return;
    }
    addVehicleMutation.mutate({
      type: vehicleType,
      plate: vehiclePlate,
    });
  };

  const getInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    return user?.email?.[0]?.toUpperCase() || "U";
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-start gap-4 mb-4">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-500/10 to-purple-600/10 border border-purple-500/20">
            <User className="w-12 h-12 text-purple-500" />
          </div>
          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Mi Perfil</h1>
            <p className="text-muted-foreground">
              Gestiona tu información, vehículos y contactos de emergencia
            </p>
          </div>
        </div>
        
        {/* User Profile */}
        <Card className="p-6">
          <div className="flex items-start gap-6 mb-6">
            <Avatar className="w-20 h-20">
              <AvatarImage src={user?.profileImageUrl || ""} />
              <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
                {getInitials()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-2xl font-bold mb-1">
                {user?.firstName && user?.lastName
                  ? `${user.firstName} ${user.lastName}`
                  : "Usuario"}
              </h2>
              <p className="text-muted-foreground mb-4">{user?.email}</p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <User className="w-4 h-4 mr-2" />
                  Editar Perfil
                </Button>
              </div>
            </div>
          </div>

          <Separator className="my-6" />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-muted-foreground" />
              <div>
                <div className="text-sm text-muted-foreground">Email</div>
                <div className="font-medium">{user?.email || "No especificado"}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-muted-foreground" />
              <div>
                <div className="text-sm text-muted-foreground">Teléfono</div>
                <div className="font-medium">{user?.phone || "No especificado"}</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Rewards Badge */}
        <RewardsBadge
          points={user?.rewardPoints || 0}
          level={user?.rewardLevel || 'bronze'}
          reportCount={user?.reportCount || 0}
          verifiedReports={user?.verifiedReports || 0}
        />

        {/* Emergency Contacts */}
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <Shield className="w-6 h-6 text-primary" />
            <h3 className="text-xl font-bold">Contactos de Emergencia</h3>
          </div>

          <div className="space-y-4 mb-6">
            {emergencyContacts && emergencyContacts.length > 0 ? (
              emergencyContacts.map((contact) => (
                <div
                  key={contact.id}
                  className="flex items-center justify-between p-4 border rounded-lg"
                  data-testid={`contact-${contact.id}`}
                >
                  <div>
                    <div className="font-medium">{contact.name}</div>
                    <div className="text-sm text-muted-foreground">{contact.phone}</div>
                  </div>
                  {contact.relationship && (
                    <div className="text-sm text-muted-foreground">{contact.relationship}</div>
                  )}
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">Sin contactos de emergencia</p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Nombre</Label>
              <Input
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                placeholder="Nombre completo"
                data-testid="input-contact-name"
              />
            </div>
            <div className="space-y-2">
              <Label>Teléfono</Label>
              <Input
                value={contactPhone}
                onChange={(e) => setContactPhone(e.target.value)}
                placeholder="+52 123 456 7890"
                data-testid="input-contact-phone"
              />
            </div>
            <div className="space-y-2">
              <Label>Relación</Label>
              <Input
                value={contactRelationship}
                onChange={(e) => setContactRelationship(e.target.value)}
                placeholder="Familiar, amigo..."
                data-testid="input-contact-relationship"
              />
            </div>
          </div>
          <Button
            onClick={handleAddContact}
            className="mt-4"
            disabled={addContactMutation.isPending}
            data-testid="button-add-contact"
          >
            Agregar Contacto
          </Button>
        </Card>

        {/* Vehicles */}
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <Car className="w-6 h-6 text-primary" />
            <h3 className="text-xl font-bold">Mis Vehículos</h3>
          </div>

          <div className="space-y-4 mb-6">
            {vehicles && vehicles.length > 0 ? (
              vehicles.map((vehicle) => (
                <div
                  key={vehicle.id}
                  className="flex items-center justify-between p-4 border rounded-lg"
                  data-testid={`vehicle-${vehicle.id}`}
                >
                  <div>
                    <div className="font-medium capitalize">{vehicle.type}</div>
                    <div className="text-sm text-muted-foreground">Placa: {vehicle.plate}</div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">Sin vehículos registrados</p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Tipo de Vehículo</Label>
              <Select value={vehicleType} onValueChange={setVehicleType}>
                <SelectTrigger data-testid="select-vehicle-type">
                  <SelectValue placeholder="Selecciona tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="car">Automóvil</SelectItem>
                  <SelectItem value="motorcycle">Motocicleta</SelectItem>
                  <SelectItem value="truck">Camión</SelectItem>
                  <SelectItem value="bus">Autobús</SelectItem>
                  <SelectItem value="van">Camioneta</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Placa</Label>
              <Input
                value={vehiclePlate}
                onChange={(e) => setVehiclePlate(e.target.value)}
                placeholder="ABC-123-D"
                data-testid="input-vehicle-plate"
              />
            </div>
          </div>
          <Button
            onClick={handleAddVehicle}
            className="mt-4"
            disabled={addVehicleMutation.isPending}
            data-testid="button-add-vehicle"
          >
            Agregar Vehículo
          </Button>
        </Card>

        {/* Maintenance Reminders */}
        <MaintenanceReminders />

        {/* Insurance Policies */}
        <InsurancePolicies />
      </div>
    </div>
  );
}
