import { useQuery } from "@tanstack/react-query";
import { AlertCard } from "@/components/AlertCard";
import { Card } from "@/components/ui/card";
import { Shield } from "lucide-react";

export default function Alerts() {
  const { data: alerts, isLoading } = useQuery<any[]>({
    queryKey: ["/api/alerts"],
  });

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando alertas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 flex items-start gap-4">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-red-500/10 to-red-600/10 border border-red-500/20">
            <Shield className="w-12 h-12 text-red-500" />
          </div>
          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Mis Alertas</h1>
            <p className="text-muted-foreground">
              Historial de activaciones del botón de pánico y alertas de seguridad
            </p>
          </div>
        </div>

        {!alerts || alerts.length === 0 ? (
          <Card className="p-12 text-center">
            <div className="flex flex-col items-center gap-4">
              <div className="p-4 rounded-full bg-primary/10">
                <Shield className="w-12 h-12 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Sin alertas registradas</h3>
              <p className="text-muted-foreground max-w-md">
                No has activado ninguna alerta todavía. El botón de pánico está disponible
                en la vista de navegación para emergencias.
              </p>
            </div>
          </Card>
        ) : (
          <div className="space-y-4">
            {alerts.map((alert) => (
              <AlertCard key={alert.id} alert={alert} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
