import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Clock, TrendingUp, Star, Calendar, Navigation, Camera, Bed, Hotel } from "lucide-react";
import type { Route, Place } from "@shared/schema";

export default function TouristRoutes() {
  const { data: touristRoutes = [], isLoading: loadingTourist } = useQuery<Route[]>({
    queryKey: ["/api/routes", { type: "tourist" }],
  });

  const { data: recommendedRoutes = [], isLoading: loadingRecommended } = useQuery<Route[]>({
    queryKey: ["/api/routes", { type: "recommended" }],
  });

  // Consultar lugares turísticos
  const { data: allPlaces = [], isLoading: loadingPlaces } = useQuery<Place[]>({
    queryKey: ["/api/places"],
  });

  // Filtrar solo lugares turísticos
  const touristPlaces = allPlaces.filter(p => p.category === 'tourism');

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-500/10 text-green-500 border-green-500/20";
      case "moderate":
        return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      case "difficult":
        return "bg-red-500/10 text-red-500 border-red-500/20";
      default:
        return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getPlaceIcon = (type: string) => {
    switch (type) {
      case 'hotel': return Hotel;
      case 'hostel': return Bed;
      case 'tourist_attraction':
      case 'museum':
      case 'viewpoint':
      case 'park':
      case 'beach':
        return Camera;
      default: return MapPin;
    }
  };

  const getPlaceLabel = (type: string) => {
    const labels: Record<string, string> = {
      hotel: 'Hotel',
      hostel: 'Hostal',
      tourist_attraction: 'Atracción',
      museum: 'Museo',
      viewpoint: 'Mirador',
      park: 'Parque',
      beach: 'Playa',
    };
    return labels[type] || type;
  };

  const PlaceCard = ({ place }: { place: Place }) => {
    const PlaceIcon = getPlaceIcon(place.type);
    
    return (
      <Card className="hover-elevate active-elevate-2" data-testid={`card-place-${place.id}`}>
        {place.imageUrl ? (
          <div className="w-full h-48 overflow-hidden rounded-t-md">
            <img 
              src={place.imageUrl} 
              alt={place.name}
              className="w-full h-full object-cover"
            />
          </div>
        ) : (
          <div className="w-full h-48 bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
            <PlaceIcon className="w-16 h-16 text-primary/40" />
          </div>
        )}
        <CardHeader>
          <div className="flex items-start justify-between gap-2">
            <CardTitle className="text-lg" data-testid={`text-place-name-${place.id}`}>
              {place.name}
            </CardTitle>
            <Badge variant="outline">{getPlaceLabel(place.type)}</Badge>
          </div>
          {place.address && (
            <CardDescription className="flex items-start gap-2">
              <MapPin className="h-4 w-4 shrink-0 mt-0.5" />
              {place.address}
            </CardDescription>
          )}
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Precio para hoteles/hostales */}
          {(place.type === 'hotel' || place.type === 'hostel') && place.pricePerNight && (
            <div>
              <span className="text-2xl font-bold text-clear-green">
                ${place.pricePerNight}
              </span>
              <span className="text-sm text-muted-foreground"> MXN / noche</span>
            </div>
          )}

          {/* Entrada para atracciones */}
          {place.entryFee !== undefined && (
            <div>
              {place.entryFee === "0" || place.entryFee === 0 ? (
                <Badge variant="secondary" className="bg-clear-green/10 text-clear-green border-clear-green/20">
                  Entrada Gratuita
                </Badge>
              ) : (
                <p className="text-sm">
                  <strong>Entrada:</strong> ${place.entryFee} MXN
                </p>
              )}
            </div>
          )}

          {place.rating && (
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 text-warning-orange fill-warning-orange" />
              <span className="font-medium">{place.rating}</span>
              <span className="text-sm text-muted-foreground">/ 5.0</span>
            </div>
          )}

          <Button 
            className="w-full" 
            variant="outline"
            data-testid={`button-view-place-${place.id}`}
          >
            Ver en Mapa
          </Button>
        </CardContent>
      </Card>
    );
  };

  const RouteCard = ({ route }: { route: Route }) => (
    <Card className="hover-elevate active-elevate-2 cursor-pointer" data-testid={`card-route-${route.id}`}>
      {route.imageUrl && (
        <div className="w-full h-48 overflow-hidden rounded-t-md">
          <img 
            src={route.imageUrl} 
            alt={route.name}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-xl" data-testid={`text-route-name-${route.id}`}>
            {route.name}
          </CardTitle>
          <Badge className={getDifficultyColor(route.difficulty || "easy")}>
            {route.difficulty === "easy" ? "Fácil" : route.difficulty === "moderate" ? "Moderada" : "Difícil"}
          </Badge>
        </div>
        <CardDescription>{route.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span data-testid={`text-route-origin-${route.id}`}>{route.startPoint}</span>
          <Navigation className="h-4 w-4" />
          <span data-testid={`text-route-destination-${route.id}`}>{route.endPoint}</span>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {route.estimatedDuration && (
            <div className="flex items-center gap-2 text-sm">
              <Clock className="h-4 w-4 text-navigation-blue" />
              <span>{route.estimatedDuration}</span>
            </div>
          )}
          {route.estimatedDistance && (
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="h-4 w-4 text-navigation-blue" />
              <span>{route.estimatedDistance} km</span>
            </div>
          )}
        </div>

        {route.bestTimeToVisit && (
          <div className="flex items-center gap-2 text-sm">
            <Calendar className="h-4 w-4 text-clear-green" />
            <span>Mejor época: {route.bestTimeToVisit}</span>
          </div>
        )}

        {route.highlights && route.highlights.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm font-medium flex items-center gap-2">
              <Star className="h-4 w-4 text-warning-orange" />
              Puntos destacados:
            </p>
            <div className="flex flex-wrap gap-2">
              {route.highlights.map((highlight, idx) => (
                <Badge key={idx} variant="outline" className="text-xs">
                  {highlight}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {route.tags && route.tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {route.tags.map((tag, idx) => (
              <Badge key={idx} variant="secondary" className="text-xs">
                #{tag}
              </Badge>
            ))}
          </div>
        )}

        <Button 
          className="w-full" 
          variant="default"
          data-testid={`button-view-route-${route.id}`}
        >
          Ver Ruta Completa
        </Button>
      </CardContent>
    </Card>
  );

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold" data-testid="text-page-title">Rutas Turísticas</h1>
        <p className="text-muted-foreground" data-testid="text-page-description">
          Descubre destinos increíbles con rutas recomendadas para tus vacaciones. 
          Lugares buenos, bonitos y baratos en México.
        </p>
      </div>

      <Tabs defaultValue="recommended" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="recommended" data-testid="tab-recommended">
            Rutas Recomendadas
          </TabsTrigger>
          <TabsTrigger value="destinations" data-testid="tab-destinations">
            Destinos Económicos
          </TabsTrigger>
          <TabsTrigger value="tourist" data-testid="tab-tourist">
            Todas las Rutas
          </TabsTrigger>
        </TabsList>

        <TabsContent value="recommended" className="mt-6">
          {loadingRecommended ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="h-96 animate-pulse bg-card" />
              ))}
            </div>
          ) : recommendedRoutes.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <p className="text-muted-foreground">
                  No hay rutas recomendadas disponibles
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recommendedRoutes.map((route) => (
                <RouteCard key={route.id} route={route} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="destinations" className="mt-6">
          <div className="mb-4">
            <h2 className="text-xl font-semibold mb-2">Hoteles y Hostales Económicos</h2>
            <p className="text-sm text-muted-foreground">
              Buenos, bonitos y baratos - Los mejores lugares para hospedarte
            </p>
          </div>
          {loadingPlaces ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="h-96 animate-pulse bg-card" />
              ))}
            </div>
          ) : touristPlaces.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <p className="text-muted-foreground">
                  No hay destinos turísticos disponibles
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {touristPlaces.map((place) => (
                <PlaceCard key={place.id} place={place} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="tourist" className="mt-6">
          {loadingTourist ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="h-96 animate-pulse bg-card" />
              ))}
            </div>
          ) : touristRoutes.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <p className="text-muted-foreground">
                  No hay rutas turísticas disponibles
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {touristRoutes.map((route) => (
                <RouteCard key={route.id} route={route} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
