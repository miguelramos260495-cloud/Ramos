import { Shield, MapPin, AlertTriangle, Building2, FileText, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function Landing() {
  const features = [
    {
      icon: MapPin,
      title: "Navegación Inteligente",
      description: "Rutas dinámicas según tu vehículo con alertas de velocidad y tipo de vía",
    },
    {
      icon: AlertTriangle,
      title: "Botón de Pánico Multinivel",
      description: "Protección instantánea: alerta roja, asistencia legal, emergencia médica",
    },
    {
      icon: Building2,
      title: "Monitoreo Empresarial",
      description: "Panel de control para flotillas con seguimiento en tiempo real",
    },
    {
      icon: FileText,
      title: "Bitácora Automática",
      description: "Registro completo de viajes, eventos y evidencias",
    },
    {
      icon: Shield,
      title: "Asistencia Legal",
      description: "Guía ante infracciones y conexión con abogados",
    },
    {
      icon: Bell,
      title: "Alertas Comunitarias",
      description: "Reportes en tiempo real de retenes, accidentes y cierres",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-background" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-primary to-primary/80">
                <Shield className="w-12 h-12 text-primary-foreground" />
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
              Sobre la Vía
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-8">
              Navegación, seguridad y asistencia vial inteligente
            </p>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-12">
              Protección 24/7 para conductores con botón de pánico, monitoreo en tiempo real,
              asistencia legal y reportes comunitarios
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="text-lg h-14 px-8"
                onClick={() => (window.location.href = "/api/login")}
                data-testid="button-login"
              >
                Iniciar Sesión
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg h-14 px-8"
                onClick={() => (window.location.href = "/api/login")}
                data-testid="button-signup"
              >
                Crear Cuenta
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
          Funciones Principales
        </h2>
        <p className="text-lg text-muted-foreground text-center mb-12 max-w-2xl mx-auto">
          Todo lo que necesitas para viajar seguro y protegido en carretera
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card
                key={index}
                className="p-6 hover-elevate active-elevate-2 transition-all"
                data-testid={`card-feature-${index}`}
              >
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-lg bg-primary/10">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-br from-primary/10 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            ¿Listo para viajar más seguro?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Únete a miles de conductores y empresas que ya confían en Sobre la Vía
          </p>
          <Button
            size="lg"
            className="text-lg h-14 px-8"
            onClick={() => (window.location.href = "/api/login")}
            data-testid="button-cta-login"
          >
            Comenzar Ahora
          </Button>
        </div>
      </div>
    </div>
  );
}
