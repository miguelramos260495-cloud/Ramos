import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Fuel, Coffee, Hotel, MapPin, Wrench, Navigation, Camera, Bed, Mountain, Palmtree } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Place } from "@shared/schema";

const placeIcons = {
  gas_station: Fuel,
  restaurant: Coffee,
  hotel: Hotel,
  rest_area: MapPin,
  mechanic: Wrench,
  tourist_attraction: Camera,
  hostel: Bed,
  viewpoint: Mountain,
  museum: Camera,
  park: Mountain,
  beach: Palmtree,
};

const placeLabels = {
  gas_station: "Gasolinera",
  restaurant: "Restaurante",
  hotel: "Hotel",
  rest_area: "Área de Descanso",
  mechanic: "Taller Mecánico",
  tourist_attraction: "Atracción Turística",
  hostel: "Hostal",
  viewpoint: "Mirador",
  museum: "Museo",
  park: "Parque",
  beach: "Playa",
};

export default function Places() {
  const { data: places, isLoading } = useQuery<Place[]>({
    queryKey: ["/api/places"],
  });

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando servicios...</p>
        </div>
      </div>
    );
  }

  // Filtrar lugares por categoría
  const roadServices = places?.filter(p => p.category === 'road_service' || !p.category) || [];
  const tourismPlaces = places?.filter(p => p.category === 'tourism') || [];

  const PlaceCard = ({ place }: { place: Place }) => {
    const Icon = placeIcons[place.type as keyof typeof placeIcons] || MapPin;
    const label = placeLabels[place.type as keyof typeof placeLabels] || place.type;

    return (
      <Card
        key={place.id}
        className="overflow-hidden hover-elevate active-elevate-2 transition-all"
        data-testid={`card-place-${place.id}`}
      >
        {place.imageUrl ? (
          <div className="h-48 bg-muted relative">
            <img
              src={place.imageUrl}
              alt={place.name}
              className="w-full h-full object-cover"
            />
          </div>
        ) : (
          <div className="h-48 bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
            <Icon className="w-16 h-16 text-primary/40" />
          </div>
        )}
        <div className="p-6">
          <div className="flex items-start justify-between gap-2 mb-3">
            <h3 className="font-semibold text-lg">{place.name}</h3>
            <Badge variant="outline">{label}</Badge>
          </div>

          {place.address && (
            <div className="flex items-start gap-2 text-sm text-muted-foreground mb-3">
              <MapPin className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{place.address}</span>
            </div>
          )}

          {/* Información específica de hoteles/hostales */}
          {(place.type === 'hotel' || place.type === 'hostel') && place.pricePerNight && (
            <div className="mb-3">
              <span className="text-lg font-bold text-green-500">
                ${place.pricePerNight} MXN
              </span>
              <span className="text-sm text-muted-foreground"> / noche</span>
            </div>
          )}

          {/* Información de lugares turísticos */}
          {place.category === 'tourism' && place.entryFee !== undefined && (
            <div className="mb-3">
              {place.entryFee === "0" || place.entryFee === 0 ? (
                <Badge variant="secondary">Entrada Gratuita</Badge>
              ) : (
                <span className="text-sm">
                  <strong>Entrada:</strong> ${place.entryFee} MXN
                </span>
              )}
            </div>
          )}

          {place.services && place.services.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {place.services.slice(0, 4).map((service: string, idx: number) => (
                <Badge key={idx} variant="secondary" className="text-xs">
                  {service}
                </Badge>
              ))}
            </div>
          )}

          <div className="flex items-center justify-between">
            {place.priceRange && (
              <span className="text-sm font-mono text-muted-foreground">
                {place.priceRange}
              </span>
            )}
            {place.rating && (
              <div className="flex items-center gap-1">
                <span className="text-sm font-medium">{place.rating}</span>
                <span className="text-xs text-muted-foreground">★</span>
              </div>
            )}
          </div>

          <Button className="w-full mt-4" variant="outline" size="sm">
            Ver en Mapa
          </Button>
        </div>
      </Card>
    );
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 flex items-start gap-4">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-green-500/10 to-green-600/10 border border-green-500/20">
            <Fuel className="w-12 h-12 text-green-500" />
          </div>
          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Lugares y Servicios</h1>
            <p className="text-muted-foreground">
              Servicios en carretera y destinos turísticos
            </p>
          </div>
        </div>

        <Tabs defaultValue="road_services" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="road_services" data-testid="tab-road-services">
              Servicios de Carretera
            </TabsTrigger>
            <TabsTrigger value="tourism" data-testid="tab-tourism">
              Lugares Turísticos
            </TabsTrigger>
          </TabsList>

          <TabsContent value="road_services" className="mt-6">
            {roadServices.length === 0 ? (
              <Card className="p-12 text-center">
                <div className="flex flex-col items-center gap-4">
                  <div className="p-4 rounded-full bg-primary/10">
                    <Fuel className="w-12 h-12 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold">Sin servicios disponibles</h3>
                  <p className="text-muted-foreground max-w-md">
                    Los servicios aparecerán aquí según tu ubicación y ruta
                  </p>
                </div>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {roadServices.map((place) => (
                  <PlaceCard key={place.id} place={place} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="tourism" className="mt-6">
            {tourismPlaces.length === 0 ? (
              <Card className="p-12 text-center">
                <div className="flex flex-col items-center gap-4">
                  <div className="p-4 rounded-full bg-primary/10">
                    <Camera className="w-12 h-12 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold">Sin lugares turísticos disponibles</h3>
                  <p className="text-muted-foreground max-w-md">
                    Lugares turísticos, hoteles y hostales económicos aparecerán aquí
                  </p>
                </div>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {tourismPlaces.map((place) => (
                  <PlaceCard key={place.id} place={place} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
