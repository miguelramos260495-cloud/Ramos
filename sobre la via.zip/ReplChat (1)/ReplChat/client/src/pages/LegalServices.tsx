import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Scale, Phone, MapPin, Star, Search } from "lucide-react";
import type { Lawyer } from "@shared/schema";

export default function LegalServices() {
  const [specialty, setSpecialty] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: lawyers = [], isLoading } = useQuery<Lawyer[]>({
    queryKey: ["/api/lawyers", specialty],
    queryFn: async () => {
      const url = specialty ? `/api/lawyers?specialty=${specialty}` : "/api/lawyers";
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch lawyers");
      return res.json();
    },
  });

  const filteredLawyers = lawyers.filter((lawyer) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      lawyer.name.toLowerCase().includes(query) ||
      lawyer.coverageStates?.some(s => s.toLowerCase().includes(query)) ||
      lawyer.specialties?.some(s => s.toLowerCase().includes(query))
    );
  });

  const getAvailabilityBadge = (availability: string | null) => {
    if (!availability) return null;
    const variants: any = {
      available: "default",
      busy: "secondary",
      unavailable: "destructive",
    };
    const labels: any = {
      available: "Disponible",
      busy: "Ocupado",
      unavailable: "No Disponible",
    };
    return (
      <Badge variant={variants[availability] || "secondary"}>
        {labels[availability] || availability}
      </Badge>
    );
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-start gap-4 mb-6">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 to-blue-600/10 border border-blue-500/20">
            <Scale className="w-12 h-12 text-blue-500" />
          </div>
          <div className="flex-1">
            <h1 className="text-3xl font-bold mb-2">Servicios Legales</h1>
            <p className="text-muted-foreground">
              Directorio de abogados especializados en transporte y tránsito
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Buscar Abogados
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                placeholder="Buscar por nombre, ubicación o especialidad..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                data-testid="input-search-lawyers"
              />
              <Select value={specialty} onValueChange={setSpecialty}>
                <SelectTrigger data-testid="select-specialty">
                  <SelectValue placeholder="Filtrar por especialidad" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todas las especialidades</SelectItem>
                  <SelectItem value="transito">Tránsito</SelectItem>
                  <SelectItem value="mercantil">Mercantil</SelectItem>
                  <SelectItem value="laboral">Laboral</SelectItem>
                  <SelectItem value="penal">Penal</SelectItem>
                  <SelectItem value="civil">Civil</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {isLoading ? (
          <p className="text-center text-muted-foreground">Cargando abogados...</p>
        ) : filteredLawyers.length === 0 ? (
          <Card>
            <CardContent className="py-8">
              <p className="text-center text-muted-foreground" data-testid="text-no-lawyers">
                No se encontraron abogados. Intenta con otros filtros.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredLawyers.map((lawyer) => (
              <Card key={lawyer.id} className="hover-elevate" data-testid={`lawyer-card-${lawyer.id}`}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-1" data-testid={`text-name-${lawyer.id}`}>
                        {lawyer.name}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-2">Lic. {lawyer.licenseNumber}</p>
                      {lawyer.rating && (
                        <div className="flex items-center gap-1 mb-2">
                          <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                          <span className="text-sm font-medium">{lawyer.rating}/5</span>
                          {lawyer.successRate && (
                            <span className="text-sm text-muted-foreground ml-2">
                              · {lawyer.successRate}% éxito
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    {getAvailabilityBadge(lawyer.availability)}
                  </div>

                  {lawyer.specialties && lawyer.specialties.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {lawyer.specialties.map((spec, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {spec}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {lawyer.coverageStates && lawyer.coverageStates.length > 0 && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                      <MapPin className="h-4 w-4" />
                      <span>{lawyer.coverageStates.join(", ")}</span>
                    </div>
                  )}

                  {lawyer.phone && (
                    <div className="flex items-center gap-2 text-sm mb-3">
                      <Phone className="h-4 w-4" />
                      <a
                        href={`tel:${lawyer.phone}`}
                        className="text-blue-600 hover:underline"
                        data-testid={`link-phone-${lawyer.id}`}
                      >
                        {lawyer.phone}
                      </a>
                    </div>
                  )}

                  {lawyer.hourlyRate && (
                    <p className="text-sm text-muted-foreground mb-2">
                      Tarifa: ${lawyer.hourlyRate}/hora
                    </p>
                  )}

                  {lawyer.email && (
                    <p className="text-sm text-muted-foreground">
                      {lawyer.email}
                    </p>
                  )}

                  <Button
                    className="w-full mt-4"
                    variant="outline"
                    data-testid={`button-contact-${lawyer.id}`}
                  >
                    Contactar
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
