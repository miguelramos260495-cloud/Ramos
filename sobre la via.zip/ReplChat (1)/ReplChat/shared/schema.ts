import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  decimal,
  boolean,
  real,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';

// Session storage table - Required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - Required for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  phone: varchar("phone"),
  userType: varchar("user_type", { enum: ['driver', 'company'] }).notNull().default('driver'),
  companyId: varchar("company_id"),
  
  // Datos de licencia de conducir (para choferes)
  licenseNumber: varchar("license_number"),
  licenseType: varchar("license_type"), // A, B, C, D, E, etc.
  licenseExpiry: timestamp("license_expiry"),
  
  // Sistema de recompensas
  rewardPoints: integer("reward_points").default(0),
  rewardLevel: varchar("reward_level").default('bronze'), // bronze, silver, gold, platinum
  reportCount: integer("report_count").default(0),
  verifiedReports: integer("verified_reports").default(0),
  
  // Última ubicación conocida (para tracking empresarial)
  lastLat: real("last_lat"),
  lastLng: real("last_lng"),
  lastLocationUpdate: timestamp("last_location_update"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Companies table
export const companies = pgTable("companies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  ownerId: varchar("owner_id").notNull(),
  phone: varchar("phone"),
  email: varchar("email"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCompanySchema = createInsertSchema(companies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;

// Vehicles table
export const vehicles = pgTable("vehicles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  companyId: varchar("company_id"),
  type: varchar("type", { enum: ['car', 'motorcycle', 'truck', 'bus', 'van', 'tractor'] }).notNull(),
  brand: varchar("brand"),
  model: varchar("model"),
  year: integer("year"),
  plate: varchar("plate").notNull(),
  color: varchar("color"),
  weight: integer("weight"), // Peso en toneladas (para tractocamiones)
  axles: integer("axles"), // Número de ejes (para clasificación de caminos)
  fuelConsumptionRate: real("fuel_consumption_rate"), // km por litro
  fuelType: varchar("fuel_type", { enum: ['magna', 'premium', 'diesel'] }), // Tipo de combustible
  tankCapacity: real("tank_capacity"), // Capacidad del tanque en litros
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Vehicle = typeof vehicles.$inferSelect;

// Emergency contacts table
export const emergencyContacts = pgTable("emergency_contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  name: varchar("name").notNull(),
  phone: varchar("phone").notNull(),
  relationship: varchar("relationship"),
  isPrimary: boolean("is_primary").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertEmergencyContactSchema = createInsertSchema(emergencyContacts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertEmergencyContact = z.infer<typeof insertEmergencyContactSchema>;
export type EmergencyContact = typeof emergencyContacts.$inferSelect;

// Trips table (Bitácora conforme a NOM-012-SCT-2-2017)
export const trips = pgTable("trips", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  vehicleId: varchar("vehicle_id").notNull(),
  
  // Datos del conductor (NOM-012)
  driverName: varchar("driver_name"), // Nombre completo del conductor
  driverLicense: varchar("driver_license"), // Número de licencia
  
  // Origen y destino detallados (NOM-012)
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  startLocation: varchar("start_location").notNull(), // Ciudad/Municipio origen
  startState: varchar("start_state"), // Estado origen
  endLocation: varchar("end_location"), // Ciudad/Municipio destino
  endState: varchar("end_state"), // Estado destino
  startLat: real("start_lat").notNull(),
  startLng: real("start_lng").notNull(),
  endLat: real("end_lat"),
  endLng: real("end_lng"),
  
  // Kilometraje (NOM-012)
  startOdometer: real("start_odometer"), // Kilometraje inicial del vehículo
  endOdometer: real("end_odometer"), // Kilometraje final del vehículo
  distance: real("distance"), // km calculados por GPS
  
  // Datos de la carga (NOM-012)
  cargoType: varchar("cargo_type"), // Tipo de mercancía
  cargoWeight: real("cargo_weight"), // Peso en toneladas
  isDangerousMaterial: boolean("is_dangerous_material").default(false),
  dangerousMaterialClass: varchar("dangerous_material_class"), // UN/NA classification
  dangerousMaterialDescription: text("dangerous_material_description"),
  visualInspectionCompleted: boolean("visual_inspection_completed").default(false),
  visualInspectionNotes: text("visual_inspection_notes"),
  
  // Velocidad y ruta
  avgSpeed: real("avg_speed"), // km/h
  maxSpeed: real("max_speed"), // km/h
  roadType: varchar("road_type", { enum: ['federal', 'state', 'municipal'] }),
  route: jsonb("route"), // Array of coordinates
  status: varchar("status", { enum: ['active', 'completed', 'cancelled'] }).default('active'),
  
  // Cálculos de ruta
  estimatedFuelLiters: real("estimated_fuel_liters"), // Litros estimados de combustible
  estimatedFuelCost: decimal("estimated_fuel_cost", { precision: 10, scale: 2 }), // Costo estimado de combustible MXN
  estimatedTollCost: decimal("estimated_toll_cost", { precision: 10, scale: 2 }), // Costo estimado de casetas MXN
  tollLocations: jsonb("toll_locations"), // Array de ubicaciones de casetas [{lat, lng, name, cost}]
  restStops: jsonb("rest_stops"), // Array de paradas de descanso sugeridas [{lat, lng, name, type}]
  fuelConsumptionRate: real("fuel_consumption_rate"), // km/litro del vehículo
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertTripSchema = createInsertSchema(trips).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTrip = z.infer<typeof insertTripSchema>;
export type Trip = typeof trips.$inferSelect;

// Alerts table (Panic button activations)
export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  tripId: varchar("trip_id"),
  type: varchar("type", { enum: ['robbery', 'legal', 'medical', 'safe_travel', 'accident'] }).notNull(),
  status: varchar("status", { enum: ['active', 'resolved', 'cancelled'] }).default('active'),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  location: varchar("location").notNull(),
  description: text("description"),
  evidenceUrls: text("evidence_urls").array(),
  notifiedContacts: text("notified_contacts").array(),
  insuranceNotified: boolean("insurance_notified").default(false), // Si se notificó al seguro
  companyNotified: boolean("company_notified").default(false), // Si se notificó a la empresa
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  resolvedAt: true,
});

export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alerts.$inferSelect;

// Places table (Service locations)
export const places = pgTable("places", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  type: varchar("type", { enum: ['gas_station', 'restaurant', 'hotel', 'rest_area', 'mechanic', 'tourist_attraction', 'hostel', 'viewpoint', 'museum', 'park', 'beach'] }).notNull(),
  category: varchar("category", { enum: ['road_service', 'tourism'] }).default('road_service'), // Categoría principal
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  address: varchar("address"),
  phone: varchar("phone"),
  services: text("services").array(), // ['bathroom', 'wifi', 'food', 'parking']
  priceRange: varchar("price_range"), // '$', '$$', '$$$'
  hours: varchar("hours"),
  rating: real("rating"),
  imageUrl: varchar("image_url"),
  
  // Precios de gasolina (solo para gas_station)
  gasolinaMagnaPrice: decimal("gasolina_magna_price", { precision: 6, scale: 2 }),
  gasolinaPremiumPrice: decimal("gasolina_premium_price", { precision: 6, scale: 2 }),
  dieselPrice: decimal("diesel_price", { precision: 6, scale: 2 }),
  lastPriceUpdate: timestamp("last_price_update"),
  
  // Información de hoteles/hostales (solo para hotel/hostel)
  pricePerNight: decimal("price_per_night", { precision: 10, scale: 2 }), // Precio promedio por noche MXN
  hasParking: boolean("has_parking").default(false),
  hasWifi: boolean("has_wifi").default(false),
  hasBreakfast: boolean("has_breakfast").default(false),
  roomTypes: text("room_types").array(), // ['individual', 'doble', 'suite']
  
  // Información turística (para lugares turísticos)
  entryFee: decimal("entry_fee", { precision: 10, scale: 2 }), // Costo de entrada MXN
  recommendedDuration: varchar("recommended_duration"), // "1-2 horas", "medio día", etc.
  bestSeason: varchar("best_season"), // "todo el año", "verano", "invierno", etc.
  // Asociación con empresa - los lugares marcados por empresa se comparten con sus conductores
  companyId: varchar("company_id"),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertPlaceSchema = createInsertSchema(places).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPlace = z.infer<typeof insertPlaceSchema>;
export type Place = typeof places.$inferSelect;

// Reports table (Community reports)
export const reports = pgTable("reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  type: varchar("type", { enum: ['checkpoint', 'accident', 'construction', 'closure', 'hazard', 'police'] }).notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  location: varchar("location").notNull(),
  description: text("description"),
  severity: varchar("severity", { enum: ['low', 'medium', 'high'] }).default('medium'),
  status: varchar("status", { enum: ['active', 'expired', 'resolved'] }).default('active'),
  confirmedBy: text("confirmed_by").array(), // Array of user IDs who confirmed
  imageUrl: varchar("image_url"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;

// Trip events table (for bitácora events)
export const tripEvents = pgTable("trip_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tripId: varchar("trip_id").notNull(),
  type: varchar("type", { 
    enum: [
      'start', 
      'stop', 
      'alert', 
      'speed_violation', 
      'infraction', 
      'refuel',
      'rest', // Descanso obligatorio
      'meal', // Comida
      'restroom', // Baño
      'inspection', // Revisión vehicular/documental
      'loading', // Carga
      'unloading', // Descarga
      'emergency', // Emergencia
      'maintenance' // Mantenimiento
    ] 
  }).notNull(),
  timestamp: timestamp("timestamp").notNull(),
  endTimestamp: timestamp("end_timestamp"), // Para registrar cuándo termina la parada
  latitude: real("latitude"),
  longitude: real("longitude"),
  location: varchar("location"),
  description: text("description"),
  stopReason: varchar("stop_reason"), // Motivo específico de la parada (NOM-012)
  currentSpeed: real("current_speed"), // Velocidad al momento del evento
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTripEventSchema = createInsertSchema(tripEvents).omit({
  id: true,
  createdAt: true,
});

export type InsertTripEvent = z.infer<typeof insertTripEventSchema>;
export type TripEvent = typeof tripEvents.$inferSelect;

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  company: one(companies, {
    fields: [users.companyId],
    references: [companies.id],
  }),
  vehicles: many(vehicles),
  emergencyContacts: many(emergencyContacts),
  trips: many(trips),
  alerts: many(alerts),
  reports: many(reports),
}));

export const companiesRelations = relations(companies, ({ one, many }) => ({
  owner: one(users, {
    fields: [companies.ownerId],
    references: [users.id],
  }),
  drivers: many(users),
  vehicles: many(vehicles),
}));

export const vehiclesRelations = relations(vehicles, ({ one, many }) => ({
  user: one(users, {
    fields: [vehicles.userId],
    references: [users.id],
  }),
  company: one(companies, {
    fields: [vehicles.companyId],
    references: [companies.id],
  }),
  trips: many(trips),
}));

export const tripsRelations = relations(trips, ({ one, many }) => ({
  user: one(users, {
    fields: [trips.userId],
    references: [users.id],
  }),
  vehicle: one(vehicles, {
    fields: [trips.vehicleId],
    references: [vehicles.id],
  }),
  events: many(tripEvents),
  alerts: many(alerts),
}));

export const alertsRelations = relations(alerts, ({ one }) => ({
  user: one(users, {
    fields: [alerts.userId],
    references: [users.id],
  }),
  trip: one(trips, {
    fields: [alerts.tripId],
    references: [trips.id],
  }),
}));

export const reportsRelations = relations(reports, ({ one }) => ({
  user: one(users, {
    fields: [reports.userId],
    references: [users.id],
  }),
}));

export const emergencyContactsRelations = relations(emergencyContacts, ({ one }) => ({
  user: one(users, {
    fields: [emergencyContacts.userId],
    references: [users.id],
  }),
}));

export const tripEventsRelations = relations(tripEvents, ({ one }) => ({
  trip: one(trips, {
    fields: [tripEvents.tripId],
    references: [trips.id],
  }),
}));

export const placesRelations = relations(places, ({ one }) => ({
  creator: one(users, {
    fields: [places.createdBy],
    references: [users.id],
  }),
}));

// Maintenance reminders table
export const maintenanceReminders = pgTable("maintenance_reminders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  vehicleId: varchar("vehicle_id").notNull(),
  type: varchar("type", { enum: ['service', 'oil_change', 'tire_rotation', 'inspection', 'license', 'insurance', 'circulation_permit', 'other'] }).notNull(),
  title: varchar("title").notNull(),
  dueDate: timestamp("due_date").notNull(),
  reminderDate: timestamp("reminder_date"),
  status: varchar("status", { enum: ['pending', 'completed', 'overdue'] }).default('pending'),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertMaintenanceReminderSchema = createInsertSchema(maintenanceReminders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertMaintenanceReminder = z.infer<typeof insertMaintenanceReminderSchema>;
export type MaintenanceReminder = typeof maintenanceReminders.$inferSelect;

export const maintenanceRemindersRelations = relations(maintenanceReminders, ({ one }) => ({
  user: one(users, {
    fields: [maintenanceReminders.userId],
    references: [users.id],
  }),
  vehicle: one(vehicles, {
    fields: [maintenanceReminders.vehicleId],
    references: [vehicles.id],
  }),
}));

// Traffic infractions table (Catálogo de infracciones)
export const infractions = pgTable("infractions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: varchar("code").notNull().unique(), // e.g., "ART-24-I"
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  category: varchar("category", { 
    enum: ['speed', 'documents', 'vehicle_condition', 'traffic_rules', 'parking', 'alcohol', 'license'] 
  }).notNull(),
  fineAmountMin: decimal("fine_amount_min", { precision: 10, scale: 2 }),
  fineAmountMax: decimal("fine_amount_max", { precision: 10, scale: 2 }),
  points: integer("points"), // Puntos en licencia
  severity: varchar("severity", { enum: ['low', 'medium', 'high', 'severe'] }).default('medium'),
  legalSteps: text("legal_steps").array(), // Pasos a seguir
  canContest: boolean("can_contest").default(true),
  contestProcess: text("contest_process"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertInfractionSchema = createInsertSchema(infractions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertInfraction = z.infer<typeof insertInfractionSchema>;
export type Infraction = typeof infractions.$inferSelect;

// Road restrictions table (Restricciones de caminos por tipo de vehículo)
export const roadRestrictions = pgTable("road_restrictions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roadType: varchar("road_type", { enum: ['federal', 'state', 'municipal', 'toll', 'urban'] }).notNull(),
  vehicleType: varchar("vehicle_type", { enum: ['car', 'motorcycle', 'truck', 'bus', 'van', 'tractor'] }).notNull(),
  maxWeight: integer("max_weight"), // Toneladas
  maxAxles: integer("max_axles"),
  maxSpeed: integer("max_speed"), // km/h
  restrictions: text("restrictions").array(), // ['no_night_travel', 'permit_required', etc]
  permitRequired: boolean("permit_required").default(false),
  permitType: varchar("permit_type"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertRoadRestrictionSchema = createInsertSchema(roadRestrictions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertRoadRestriction = z.infer<typeof insertRoadRestrictionSchema>;
export type RoadRestriction = typeof roadRestrictions.$inferSelect;

// Vehicle status table (Real-time tracking for fleet management)
export const vehicleStatus = pgTable("vehicle_status", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  vehicleId: varchar("vehicle_id").notNull().unique(),
  userId: varchar("user_id").notNull(), // Driver currently operating
  companyId: varchar("company_id"), // Company that owns the vehicle
  tripId: varchar("trip_id"), // Current active trip
  currentLat: real("current_lat").notNull(),
  currentLng: real("current_lng").notNull(),
  currentLocation: varchar("current_location"),
  currentSpeed: real("current_speed"), // km/h
  heading: real("heading"), // Degrees 0-360
  status: varchar("status", { 
    enum: ['en_ruta', 'descargando', 'cargando', 'destino', 'descansando', 'taller', 'estacionado', 'inactivo'] 
  }).notNull().default('en_ruta'),
  batteryLevel: integer("battery_level"), // Device battery %
  lastUpdate: timestamp("last_update").notNull().defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertVehicleStatusSchema = createInsertSchema(vehicleStatus).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertVehicleStatus = z.infer<typeof insertVehicleStatusSchema>;
export type VehicleStatus = typeof vehicleStatus.$inferSelect;

export const vehicleStatusRelations = relations(vehicleStatus, ({ one }) => ({
  vehicle: one(vehicles, {
    fields: [vehicleStatus.vehicleId],
    references: [vehicles.id],
  }),
  user: one(users, {
    fields: [vehicleStatus.userId],
    references: [users.id],
  }),
  company: one(companies, {
    fields: [vehicleStatus.companyId],
    references: [companies.id],
  }),
  trip: one(trips, {
    fields: [vehicleStatus.tripId],
    references: [trips.id],
  }),
}));

// National Guard locations table (Ubicaciones de Guardia Nacional)
export const nationalGuardLocations = pgTable("national_guard_locations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  address: varchar("address"),
  phone: varchar("phone"),
  type: varchar("type", { enum: ['base', 'checkpoint', 'patrol'] }).notNull(),
  operatingHours: varchar("operating_hours"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertNationalGuardLocationSchema = createInsertSchema(nationalGuardLocations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertNationalGuardLocation = z.infer<typeof insertNationalGuardLocationSchema>;
export type NationalGuardLocation = typeof nationalGuardLocations.$inferSelect;

// Automatic alerts table (Alertas automáticas por sobrepeso, vía no autorizada, etc.)
export const automaticAlerts = pgTable("automatic_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  vehicleId: varchar("vehicle_id").notNull(),
  tripId: varchar("trip_id"),
  type: varchar("type", { 
    enum: ['overweight', 'unauthorized_road', 'speeding', 'restricted_hours', 'rest_required'] 
  }).notNull(),
  severity: varchar("severity", { enum: ['low', 'medium', 'high', 'critical'] }).default('medium'),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  location: varchar("location"),
  description: text("description").notNull(),
  currentWeight: real("current_weight"), // Peso actual en toneladas
  maxAllowedWeight: real("max_allowed_weight"), // Peso máximo permitido
  currentRoadType: varchar("current_road_type"),
  nearestAuthority: varchar("nearest_authority"), // ID de Guardia Nacional más cercana
  distanceToAuthority: real("distance_to_authority"), // km a la autoridad
  status: varchar("status", { enum: ['active', 'acknowledged', 'resolved'] }).default('active'),
  notifiedAt: timestamp("notified_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertAutomaticAlertSchema = createInsertSchema(automaticAlerts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  notifiedAt: true,
  resolvedAt: true,
});

export type InsertAutomaticAlert = z.infer<typeof insertAutomaticAlertSchema>;
export type AutomaticAlert = typeof automaticAlerts.$inferSelect;

export const automaticAlertsRelations = relations(automaticAlerts, ({ one }) => ({
  user: one(users, {
    fields: [automaticAlerts.userId],
    references: [users.id],
  }),
  vehicle: one(vehicles, {
    fields: [automaticAlerts.vehicleId],
    references: [vehicles.id],
  }),
  trip: one(trips, {
    fields: [automaticAlerts.tripId],
    references: [trips.id],
  }),
}));

// Insurance policies table (Pólizas de seguro)
export const insurancePolicies = pgTable("insurance_policies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  vehicleId: varchar("vehicle_id"), // Optional - policy can be general or specific to a vehicle
  userId: varchar("user_id").notNull(),
  companyId: varchar("company_id"), // Empresa dueña del vehículo
  insuranceCompany: varchar("insurance_company").notNull(),
  policyNumber: varchar("policy_number").notNull(),
  phoneNumber: varchar("phone_number").notNull(), // Número para reportar accidentes
  emergencyPhone: varchar("emergency_phone"), // Línea de emergencias 24/7
  coverageType: varchar("coverage_type", { 
    enum: ['liability', 'comprehensive', 'collision', 'full'] 
  }).notNull(),
  coverageAmount: decimal("coverage_amount", { precision: 12, scale: 2 }),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: varchar("status", { enum: ['active', 'expired', 'cancelled'] }).default('active'),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertInsurancePolicySchema = createInsertSchema(insurancePolicies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  startDate: z.union([z.string(), z.date()]).transform(val => typeof val === 'string' ? new Date(val) : val),
  endDate: z.union([z.string(), z.date()]).transform(val => typeof val === 'string' ? new Date(val) : val),
});

export type InsertInsurancePolicy = z.infer<typeof insertInsurancePolicySchema>;
export type InsurancePolicy = typeof insurancePolicies.$inferSelect;

export const insurancePoliciesRelations = relations(insurancePolicies, ({ one }) => ({
  vehicle: one(vehicles, {
    fields: [insurancePolicies.vehicleId],
    references: [vehicles.id],
  }),
  user: one(users, {
    fields: [insurancePolicies.userId],
    references: [users.id],
  }),
  company: one(companies, {
    fields: [insurancePolicies.companyId],
    references: [companies.id],
  }),
}));

// Traffic blocks table (Bloqueos de tráfico)
export const trafficBlocks = pgTable("traffic_blocks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reportedBy: varchar("reported_by"), // User ID que reportó
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  location: varchar("location").notNull(),
  type: varchar("type", { 
    enum: ['accident', 'construction', 'protest', 'weather', 'police', 'other'] 
  }).notNull(),
  severity: varchar("severity", { enum: ['low', 'medium', 'high', 'critical'] }).default('medium'),
  description: text("description").notNull(),
  estimatedDuration: integer("estimated_duration"), // Minutos estimados de bloqueo
  estimatedClearTime: timestamp("estimated_clear_time"), // Hora estimada de despeje
  affectedLanes: integer("affected_lanes"), // Carriles afectados
  totalLanes: integer("total_lanes"), // Total de carriles
  alternativeRoute: text("alternative_route"), // Descripción de ruta alternativa
  status: varchar("status", { enum: ['active', 'clearing', 'cleared'] }).default('active'),
  confirmedBy: text("confirmed_by").array(), // User IDs que confirmaron
  lastUpdate: timestamp("last_update").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertTrafficBlockSchema = createInsertSchema(trafficBlocks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastUpdate: true,
});

export type InsertTrafficBlock = z.infer<typeof insertTrafficBlockSchema>;
export type TrafficBlock = typeof trafficBlocks.$inferSelect;

export const trafficBlocksRelations = relations(trafficBlocks, ({ one }) => ({
  reporter: one(users, {
    fields: [trafficBlocks.reportedBy],
    references: [users.id],
  }),
}));

// Legal services table (Servicios legales para impugnación)
export const legalServices = pgTable("legal_services", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  infractionCode: varchar("infraction_code"), // Código de la infracción
  ticketNumber: varchar("ticket_number"), // Número de boleta
  officerName: varchar("officer_name"), // Nombre del oficial
  issueDate: timestamp("issue_date").notNull(),
  location: varchar("location").notNull(),
  description: text("description").notNull(),
  fineAmount: decimal("fine_amount", { precision: 10, scale: 2 }),
  status: varchar("status", { 
    enum: ['pending', 'in_review', 'appealing', 'won', 'lost', 'paid'] 
  }).default('pending'),
  wantsToAppeal: boolean("wants_to_appeal").default(false), // Si quiere impugnar
  appealReason: text("appeal_reason"), // Razón para impugnar
  evidenceUrls: text("evidence_urls").array(), // Fotos/videos de evidencia
  lawyerAssigned: varchar("lawyer_assigned"), // Abogado asignado
  lawyerNotes: text("lawyer_notes"),
  courtDate: timestamp("court_date"),
  resolution: text("resolution"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertLegalServiceSchema = createInsertSchema(legalServices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertLegalService = z.infer<typeof insertLegalServiceSchema>;
export type LegalService = typeof legalServices.$inferSelect;

export const legalServicesRelations = relations(legalServices, ({ one }) => ({
  user: one(users, {
    fields: [legalServices.userId],
    references: [users.id],
  }),
}));

// Lawyers directory table (Directorio de abogados)
export const lawyers = pgTable("lawyers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  licenseNumber: varchar("license_number").notNull(),
  phone: varchar("phone").notNull(),
  email: varchar("email"),
  specialties: text("specialties").array(), // ['traffic', 'criminal', 'civil']
  rating: real("rating"),
  reviewCount: integer("review_count").default(0),
  successRate: real("success_rate"), // Porcentaje de casos ganados
  availability: varchar("availability", { enum: ['available', 'busy', 'unavailable'] }).default('available'),
  hourlyRate: decimal("hourly_rate", { precision: 10, scale: 2 }),
  coverageStates: text("coverage_states").array(), // Estados donde opera
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertLawyerSchema = createInsertSchema(lawyers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertLawyer = z.infer<typeof insertLawyerSchema>;
export type Lawyer = typeof lawyers.$inferSelect;

// Messages table - Mensajería entre empresa y chofer
export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").notNull(), // ID del usuario que envía (empresa o chofer)
  receiverId: varchar("receiver_id").notNull(), // ID del usuario que recibe
  companyId: varchar("company_id"), // ID de la empresa (para filtrar conversaciones)
  subject: varchar("subject"),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false),
  readAt: timestamp("read_at"),
  priority: varchar("priority", { enum: ['low', 'normal', 'high', 'urgent'] }).default('normal'),
  type: varchar("type", { enum: ['message', 'alert', 'instruction', 'report'] }).default('message'),
  attachmentUrl: varchar("attachment_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Routes table - Rutas recomendadas para turistas y rutas personalizadas para empresas
export const routes = pgTable("routes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  routeType: varchar("route_type", { enum: ['tourist', 'business', 'recommended'] }).notNull(), // tourist: rutas turísticas, business: rutas de empresa, recommended: rutas recomendadas del sistema
  startPoint: varchar("start_point").notNull(), // Ciudad/lugar de inicio
  endPoint: varchar("end_point").notNull(), // Ciudad/lugar de destino
  waypoints: text("waypoints").array(), // Puntos intermedios en formato "lat,lng" o lugar
  estimatedDuration: varchar("estimated_duration"), // "3-4 horas", "1 día", etc.
  estimatedDistance: real("estimated_distance"), // Distancia en km
  difficulty: varchar("difficulty", { enum: ['easy', 'moderate', 'difficult'] }).default('easy'),
  bestTimeToVisit: varchar("best_time_to_visit"), // "Todo el año", "Verano", etc.
  highlights: text("highlights").array(), // Puntos destacados del recorrido
  recommendedPlaces: text("recommended_places").array(), // IDs de lugares recomendados en la ruta
  tags: text("tags").array(), // ['playa', 'montaña', 'cultural', 'aventura']
  imageUrl: varchar("image_url"),
  // Para rutas de empresa
  companyId: varchar("company_id"), // Si es ruta de empresa, ID de la empresa
  isPublic: boolean("is_public").default(true), // Si la ruta es pública o privada (solo empresa)
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertRouteSchema = createInsertSchema(routes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertRoute = z.infer<typeof insertRouteSchema>;
export type Route = typeof routes.$inferSelect;

// Whitelist table - Control de acceso para pruebas piloto
export const whitelist = pgTable("whitelist", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phone: varchar("phone").notNull().unique(), // Número de teléfono autorizado
  name: varchar("name"), // Nombre del tester (opcional)
  userType: varchar("user_type", { enum: ['driver', 'company'] }), // Tipo de usuario
  notes: text("notes"), // Notas sobre el tester
  isActive: boolean("is_active").default(true), // Si está activo o deshabilitado
  addedBy: varchar("added_by").notNull(), // Email del administrador que lo agregó
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertWhitelistSchema = createInsertSchema(whitelist).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertWhitelist = z.infer<typeof insertWhitelistSchema>;
export type Whitelist = typeof whitelist.$inferSelect;
