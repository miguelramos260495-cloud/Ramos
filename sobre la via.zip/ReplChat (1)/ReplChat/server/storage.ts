import {
  users,
  vehicles,
  emergencyContacts,
  trips,
  alerts,
  reports,
  places,
  tripEvents,
  maintenanceReminders,
  infractions,
  roadRestrictions,
  vehicleStatus,
  automaticAlerts,
  nationalGuardLocations,
  insurancePolicies,
  trafficBlocks,
  legalServices,
  lawyers,
  messages,
  routes,
  whitelist,
  type User,
  type UpsertUser,
  type Vehicle,
  type InsertVehicle,
  type EmergencyContact,
  type InsertEmergencyContact,
  type Trip,
  type InsertTrip,
  type Alert,
  type InsertAlert,
  type Report,
  type InsertReport,
  type Place,
  type InsertPlace,
  type TripEvent,
  type InsertTripEvent,
  type MaintenanceReminder,
  type InsertMaintenanceReminder,
  type Infraction,
  type RoadRestriction,
  type VehicleStatus,
  type InsertVehicleStatus,
  type AutomaticAlert,
  type InsertAutomaticAlert,
  type NationalGuardLocation,
  type InsertNationalGuardLocation,
  type InsurancePolicy,
  type InsertInsurancePolicy,
  type TrafficBlock,
  type InsertTrafficBlock,
  type LegalService,
  type InsertLegalService,
  type Lawyer,
  type InsertLawyer,
  type Message,
  type InsertMessage,
  type Route,
  type InsertRoute,
  type Whitelist,
  type InsertWhitelist,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, asc, or, isNull, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<UpsertUser>): Promise<User>;

  // Vehicle operations
  getVehiclesByUser(userId: string): Promise<Vehicle[]>;
  getVehiclesByCompany(companyId: string): Promise<Vehicle[]>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  
  // Emergency contacts
  getEmergencyContacts(userId: string): Promise<EmergencyContact[]>;
  createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;
  
  // Trip operations
  getTripsByUser(userId: string): Promise<Trip[]>;
  getTripsByCompany(companyId: string): Promise<Trip[]>;
  createTrip(trip: InsertTrip): Promise<Trip>;
  updateTrip(id: string, trip: Partial<InsertTrip>): Promise<Trip>;
  
  // Alert operations
  getAlertsByUser(userId: string): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: string, alert: Partial<InsertAlert>): Promise<Alert>;
  
  // Report operations
  getActiveReports(): Promise<Report[]>;
  createReport(report: InsertReport): Promise<Report>;
  
  // Place operations
  getAllPlaces(): Promise<Place[]>;
  getPlacesByCompany(companyId: string | null): Promise<Place[]>;
  createPlace(place: InsertPlace): Promise<Place>;
  updatePlace(id: string, updates: Partial<InsertPlace>): Promise<Place>;
  
  // Trip event operations
  getTripEvents(tripId: string): Promise<TripEvent[]>;
  createTripEvent(event: InsertTripEvent): Promise<TripEvent>;

  // Maintenance reminder operations
  getMaintenanceReminders(userId: string): Promise<MaintenanceReminder[]>;
  getMaintenanceRemindersByVehicle(vehicleId: string): Promise<MaintenanceReminder[]>;
  getOverdueReminders(userId: string): Promise<MaintenanceReminder[]>;
  createMaintenanceReminder(reminder: InsertMaintenanceReminder): Promise<MaintenanceReminder>;
  updateMaintenanceReminder(id: string, updates: Partial<InsertMaintenanceReminder>): Promise<MaintenanceReminder>;
  deleteMaintenanceReminder(id: string): Promise<void>;

  // Infraction operations
  getAllInfractions(): Promise<Infraction[]>;
  getInfractionByCode(code: string): Promise<Infraction | undefined>;
  searchInfractions(category?: string): Promise<Infraction[]>;

  // Road restriction operations
  getRoadRestrictions(vehicleType: string): Promise<RoadRestriction[]>;
  getRoadRestrictionsByType(roadType: string, vehicleType: string): Promise<RoadRestriction | undefined>;

  // Vehicle status operations (real-time tracking)
  getVehicleStatus(vehicleId: string): Promise<VehicleStatus | undefined>;
  getCompanyVehiclesStatus(companyId: string): Promise<VehicleStatus[]>;
  upsertVehicleStatus(status: InsertVehicleStatus): Promise<VehicleStatus>;

  // Insurance policy operations
  getVehicleInsurance(vehicleId: string): Promise<InsurancePolicy | undefined>;
  getUserInsurances(userId: string): Promise<InsurancePolicy[]>;
  getCompanyInsurances(companyId: string): Promise<InsurancePolicy[]>;
  getExpiringInsurances(userId: string, daysThreshold: number): Promise<InsurancePolicy[]>;
  createInsurancePolicy(policy: InsertInsurancePolicy): Promise<InsurancePolicy>;
  updateInsurancePolicy(id: string, updates: Partial<InsertInsurancePolicy>): Promise<InsurancePolicy>;
  deleteInsurancePolicy(id: string): Promise<void>;

  // Traffic block operations
  getActiveTrafficBlocks(): Promise<TrafficBlock[]>;
  createTrafficBlock(block: InsertTrafficBlock): Promise<TrafficBlock>;
  updateTrafficBlock(id: string, updates: Partial<InsertTrafficBlock>): Promise<TrafficBlock>;

  // Automatic alert operations
  getAutomaticAlerts(userId: string): Promise<AutomaticAlert[]>;
  getCompanyAutomaticAlerts(companyId: string): Promise<AutomaticAlert[]>;
  createAutomaticAlert(alert: InsertAutomaticAlert): Promise<AutomaticAlert>;
  updateAutomaticAlert(id: string, updates: Partial<InsertAutomaticAlert>): Promise<AutomaticAlert>;

  // National Guard location operations
  getNearestNationalGuard(lat: number, lng: number): Promise<NationalGuardLocation | undefined>;
  getAllNationalGuardLocations(): Promise<NationalGuardLocation[]>;

  // Legal services operations
  getUserLegalServices(userId: string): Promise<LegalService[]>;
  getLegalService(id: string): Promise<LegalService | undefined>;
  createLegalService(service: InsertLegalService): Promise<LegalService>;
  updateLegalService(id: string, updates: Partial<InsertLegalService>): Promise<LegalService>;
  deleteLegalService(id: string): Promise<void>;

  // Lawyer operations
  getAllLawyers(): Promise<Lawyer[]>;
  getLawyer(id: string): Promise<Lawyer | undefined>;
  getAvailableLawyers(specialty?: string): Promise<Lawyer[]>;
  createLawyer(lawyer: InsertLawyer): Promise<Lawyer>;
  updateLawyer(id: string, updates: Partial<InsertLawyer>): Promise<Lawyer>;

  // Message operations (comunicación empresa-chofer)
  getMessagesByUser(userId: string): Promise<Message[]>;
  getConversation(userId1: string, userId2: string): Promise<Message[]>;
  getUnreadMessagesCount(userId: string): Promise<number>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: string): Promise<Message>;
  getDriversByCompany(companyId: string): Promise<User[]>;
  deleteLawyer(id: string): Promise<void>;

  // Route operations (rutas turísticas y empresariales)
  getAllRoutes(): Promise<Route[]>;
  getRoutesByType(routeType: 'tourist' | 'business' | 'recommended'): Promise<Route[]>;
  getCompanyRoutes(companyId: string): Promise<Route[]>;
  getRouteById(id: string): Promise<Route | undefined>;
  createRoute(route: InsertRoute): Promise<Route>;
  updateRoute(id: string, updates: Partial<InsertRoute>): Promise<Route>;
  deleteRoute(id: string): Promise<void>;

  // Whitelist operations (control de acceso para pruebas piloto)
  getAllWhitelist(): Promise<Whitelist[]>;
  getWhitelistByPhone(phone: string): Promise<Whitelist | undefined>;
  checkWhitelistAccess(phone: string): Promise<boolean>;
  addWhitelist(entry: InsertWhitelist): Promise<Whitelist>;
  updateWhitelist(id: string, updates: Partial<InsertWhitelist>): Promise<Whitelist>;
  deleteWhitelist(id: string): Promise<void>;
  toggleWhitelist(id: string, isActive: boolean): Promise<Whitelist>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.email,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<UpsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Vehicle operations
  async getVehiclesByUser(userId: string): Promise<Vehicle[]> {
    return await db.select().from(vehicles).where(eq(vehicles.userId, userId));
  }

  async getVehiclesByCompany(companyId: string): Promise<Vehicle[]> {
    return await db.select().from(vehicles).where(eq(vehicles.companyId, companyId));
  }

  async createVehicle(vehicleData: InsertVehicle): Promise<Vehicle> {
    const [vehicle] = await db.insert(vehicles).values(vehicleData).returning();
    return vehicle;
  }

  // Emergency contacts
  async getEmergencyContacts(userId: string): Promise<EmergencyContact[]> {
    return await db
      .select()
      .from(emergencyContacts)
      .where(eq(emergencyContacts.userId, userId));
  }

  async createEmergencyContact(contactData: InsertEmergencyContact): Promise<EmergencyContact> {
    const [contact] = await db.insert(emergencyContacts).values(contactData).returning();
    return contact;
  }

  // Trip operations
  async getTripsByUser(userId: string): Promise<Trip[]> {
    return await db
      .select()
      .from(trips)
      .where(eq(trips.userId, userId))
      .orderBy(desc(trips.startTime));
  }

  async getTripsByCompany(companyId: string): Promise<Trip[]> {
    // Get all drivers of the company
    const drivers = await db
      .select()
      .from(users)
      .where(
        and(
          eq(users.companyId, companyId),
          eq(users.userType, 'driver')
        )
      );
    
    if (drivers.length === 0) {
      return [];
    }

    // Get all trips from these drivers
    const driverIds = drivers.map(d => d.id);
    const companyTrips = await db
      .select()
      .from(trips)
      .where(
        or(...driverIds.map(id => eq(trips.userId, id)))
      )
      .orderBy(desc(trips.startTime));
    
    return companyTrips;
  }

  async createTrip(tripData: InsertTrip): Promise<Trip> {
    const [trip] = await db.insert(trips).values(tripData).returning();
    return trip;
  }

  async updateTrip(id: string, tripData: Partial<InsertTrip>): Promise<Trip> {
    const [trip] = await db
      .update(trips)
      .set({ ...tripData, updatedAt: new Date() })
      .where(eq(trips.id, id))
      .returning();
    return trip;
  }

  // Alert operations
  async getAlertsByUser(userId: string): Promise<Alert[]> {
    return await db
      .select()
      .from(alerts)
      .where(eq(alerts.userId, userId))
      .orderBy(desc(alerts.createdAt));
  }

  async createAlert(alertData: InsertAlert): Promise<Alert> {
    const [alert] = await db.insert(alerts).values(alertData).returning();
    return alert;
  }

  async updateAlert(id: string, alertData: Partial<InsertAlert>): Promise<Alert> {
    const [alert] = await db
      .update(alerts)
      .set({ ...alertData, updatedAt: new Date() })
      .where(eq(alerts.id, id))
      .returning();
    return alert;
  }

  // Report operations
  async getActiveReports(): Promise<Report[]> {
    return await db
      .select()
      .from(reports)
      .where(eq(reports.status, 'active'))
      .orderBy(desc(reports.createdAt));
  }

  async createReport(reportData: InsertReport): Promise<Report> {
    const [report] = await db.insert(reports).values(reportData).returning();
    return report;
  }

  // Place operations
  async getAllPlaces(): Promise<Place[]> {
    return await db.select().from(places);
  }

  async getPlacesByCompany(companyId: string | null): Promise<Place[]> {
    if (companyId) {
      // Return public places AND company-specific places
      return await db.select().from(places).where(
        or(
          isNull(places.companyId),
          eq(places.companyId, companyId)
        )
      );
    }
    // Return only public places for non-company users
    return await db.select().from(places).where(isNull(places.companyId));
  }

  async createPlace(placeData: InsertPlace): Promise<Place> {
    const [place] = await db.insert(places).values(placeData).returning();
    return place;
  }

  async updatePlace(id: string, placeData: Partial<InsertPlace>): Promise<Place> {
    const [place] = await db
      .update(places)
      .set({ ...placeData, updatedAt: new Date() })
      .where(eq(places.id, id))
      .returning();
    return place;
  }

  // Trip event operations
  async getTripEvents(tripId: string): Promise<TripEvent[]> {
    return await db
      .select()
      .from(tripEvents)
      .where(eq(tripEvents.tripId, tripId))
      .orderBy(desc(tripEvents.timestamp));
  }

  async createTripEvent(eventData: InsertTripEvent): Promise<TripEvent> {
    const [event] = await db.insert(tripEvents).values(eventData).returning();
    return event;
  }

  // Maintenance reminder operations
  async getMaintenanceReminders(userId: string): Promise<MaintenanceReminder[]> {
    return await db
      .select()
      .from(maintenanceReminders)
      .where(eq(maintenanceReminders.userId, userId))
      .orderBy(asc(maintenanceReminders.dueDate));
  }

  async createMaintenanceReminder(reminderData: InsertMaintenanceReminder): Promise<MaintenanceReminder> {
    const [reminder] = await db.insert(maintenanceReminders).values(reminderData).returning();
    return reminder;
  }

  async updateMaintenanceReminder(id: string, updates: Partial<InsertMaintenanceReminder>): Promise<MaintenanceReminder> {
    const [reminder] = await db
      .update(maintenanceReminders)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(maintenanceReminders.id, id))
      .returning();
    return reminder;
  }

  async getMaintenanceRemindersByVehicle(vehicleId: string): Promise<MaintenanceReminder[]> {
    return await db
      .select()
      .from(maintenanceReminders)
      .where(eq(maintenanceReminders.vehicleId, vehicleId))
      .orderBy(asc(maintenanceReminders.dueDate));
  }

  async getOverdueReminders(userId: string): Promise<MaintenanceReminder[]> {
    const now = new Date();
    return await db
      .select()
      .from(maintenanceReminders)
      .where(
        and(
          eq(maintenanceReminders.userId, userId),
          eq(maintenanceReminders.status, 'pending'),
          sql`${maintenanceReminders.dueDate} < ${now}`
        )
      )
      .orderBy(asc(maintenanceReminders.dueDate));
  }

  async deleteMaintenanceReminder(id: string): Promise<void> {
    await db.delete(maintenanceReminders).where(eq(maintenanceReminders.id, id));
  }

  // Infraction operations
  async getAllInfractions(): Promise<Infraction[]> {
    return await db.select().from(infractions).orderBy(asc(infractions.category));
  }

  async getInfractionByCode(code: string): Promise<Infraction | undefined> {
    const [infraction] = await db.select().from(infractions).where(eq(infractions.code, code));
    return infraction;
  }

  async searchInfractions(category?: string): Promise<Infraction[]> {
    if (category) {
      return await db.select().from(infractions).where(eq(infractions.category, category as any));
    }
    return this.getAllInfractions();
  }

  // Road restriction operations
  async getRoadRestrictions(vehicleType: string): Promise<RoadRestriction[]> {
    return await db
      .select()
      .from(roadRestrictions)
      .where(eq(roadRestrictions.vehicleType, vehicleType as any));
  }

  async getRoadRestrictionsByType(roadType: string, vehicleType: string): Promise<RoadRestriction | undefined> {
    const [restriction] = await db
      .select()
      .from(roadRestrictions)
      .where(and(
        eq(roadRestrictions.roadType, roadType as any), 
        eq(roadRestrictions.vehicleType, vehicleType as any)
      ));
    return restriction;
  }

  // Vehicle status operations (real-time tracking)
  async getVehicleStatus(vehicleId: string): Promise<VehicleStatus | undefined> {
    const [status] = await db
      .select()
      .from(vehicleStatus)
      .where(eq(vehicleStatus.vehicleId, vehicleId));
    return status;
  }

  async getCompanyVehiclesStatus(companyId: string): Promise<VehicleStatus[]> {
    return await db
      .select()
      .from(vehicleStatus)
      .where(eq(vehicleStatus.companyId, companyId));
  }

  async upsertVehicleStatus(statusData: InsertVehicleStatus): Promise<VehicleStatus> {
    const [status] = await db
      .insert(vehicleStatus)
      .values({ ...statusData, lastUpdate: new Date() })
      .onConflictDoUpdate({
        target: vehicleStatus.vehicleId,
        set: {
          ...statusData,
          lastUpdate: new Date(),
          updatedAt: new Date(),
        },
      })
      .returning();
    return status;
  }

  // Insurance policy operations
  async getVehicleInsurance(vehicleId: string): Promise<InsurancePolicy | undefined> {
    const [policy] = await db
      .select()
      .from(insurancePolicies)
      .where(eq(insurancePolicies.vehicleId, vehicleId));
    return policy;
  }

  async getUserInsurances(userId: string): Promise<InsurancePolicy[]> {
    return await db
      .select()
      .from(insurancePolicies)
      .where(eq(insurancePolicies.userId, userId));
  }

  async createInsurancePolicy(policyData: InsertInsurancePolicy): Promise<InsurancePolicy> {
    const [policy] = await db.insert(insurancePolicies).values(policyData).returning();
    return policy;
  }

  async getCompanyInsurances(companyId: string): Promise<InsurancePolicy[]> {
    return await db
      .select()
      .from(insurancePolicies)
      .where(eq(insurancePolicies.companyId, companyId));
  }

  async getExpiringInsurances(userId: string, daysThreshold: number = 30): Promise<InsurancePolicy[]> {
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + daysThreshold);
    
    return await db
      .select()
      .from(insurancePolicies)
      .where(
        and(
          eq(insurancePolicies.userId, userId),
          eq(insurancePolicies.status, 'active'),
          sql`${insurancePolicies.endDate} <= ${futureDate}`
        )
      )
      .orderBy(asc(insurancePolicies.endDate));
  }

  async updateInsurancePolicy(id: string, updates: Partial<InsertInsurancePolicy>): Promise<InsurancePolicy> {
    const [policy] = await db
      .update(insurancePolicies)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(insurancePolicies.id, id))
      .returning();
    return policy;
  }

  async deleteInsurancePolicy(id: string): Promise<void> {
    await db.delete(insurancePolicies).where(eq(insurancePolicies.id, id));
  }

  // Traffic block operations
  async getActiveTrafficBlocks(): Promise<TrafficBlock[]> {
    return await db
      .select()
      .from(trafficBlocks)
      .where(eq(trafficBlocks.status, 'active'))
      .orderBy(desc(trafficBlocks.createdAt));
  }

  async createTrafficBlock(blockData: InsertTrafficBlock): Promise<TrafficBlock> {
    const [block] = await db.insert(trafficBlocks).values(blockData).returning();
    return block;
  }

  async updateTrafficBlock(id: string, updates: Partial<InsertTrafficBlock>): Promise<TrafficBlock> {
    const [block] = await db
      .update(trafficBlocks)
      .set({ ...updates, lastUpdate: new Date(), updatedAt: new Date() })
      .where(eq(trafficBlocks.id, id))
      .returning();
    return block;
  }

  // Automatic alert operations
  async getAutomaticAlerts(userId: string): Promise<AutomaticAlert[]> {
    return await db
      .select()
      .from(automaticAlerts)
      .where(eq(automaticAlerts.userId, userId))
      .orderBy(desc(automaticAlerts.createdAt));
  }

  async getCompanyAutomaticAlerts(companyId: string): Promise<AutomaticAlert[]> {
    // Get all automatic alerts for vehicles belonging to this company
    const vehicles = await db
      .select()
      .from(vehicleStatus)
      .where(eq(vehicleStatus.companyId, companyId));
    
    const vehicleIds = vehicles.map(v => v.vehicleId);
    
    if (vehicleIds.length === 0) return [];
    
    return await db
      .select()
      .from(automaticAlerts)
      .where(or(...vehicleIds.map(id => eq(automaticAlerts.vehicleId, id))))
      .orderBy(desc(automaticAlerts.createdAt));
  }

  async createAutomaticAlert(alertData: InsertAutomaticAlert): Promise<AutomaticAlert> {
    const [alert] = await db.insert(automaticAlerts).values(alertData).returning();
    return alert;
  }

  async updateAutomaticAlert(id: string, updates: Partial<InsertAutomaticAlert>): Promise<AutomaticAlert> {
    const [alert] = await db
      .update(automaticAlerts)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(automaticAlerts.id, id))
      .returning();
    return alert;
  }

  // National Guard location operations
  async getNearestNationalGuard(lat: number, lng: number): Promise<NationalGuardLocation | undefined> {
    // Simple implementation - get all and find nearest
    // In production, use PostGIS for proper geospatial queries
    const locations = await db.select().from(nationalGuardLocations);
    
    if (locations.length === 0) return undefined;
    
    const withDistance = locations.map(loc => ({
      ...loc,
      distance: Math.sqrt(
        Math.pow(loc.latitude - lat, 2) + 
        Math.pow(loc.longitude - lng, 2)
      )
    }));
    
    withDistance.sort((a, b) => a.distance - b.distance);
    return withDistance[0];
  }

  async getAllNationalGuardLocations(): Promise<NationalGuardLocation[]> {
    return await db.select().from(nationalGuardLocations);
  }

  // Legal services operations
  async getUserLegalServices(userId: string): Promise<LegalService[]> {
    return await db
      .select()
      .from(legalServices)
      .where(eq(legalServices.userId, userId))
      .orderBy(desc(legalServices.createdAt));
  }

  async getLegalService(id: string): Promise<LegalService | undefined> {
    const [service] = await db
      .select()
      .from(legalServices)
      .where(eq(legalServices.id, id));
    return service;
  }

  async createLegalService(serviceData: InsertLegalService): Promise<LegalService> {
    const [service] = await db.insert(legalServices).values(serviceData).returning();
    return service;
  }

  async updateLegalService(id: string, updates: Partial<InsertLegalService>): Promise<LegalService> {
    const [service] = await db
      .update(legalServices)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(legalServices.id, id))
      .returning();
    return service;
  }

  async deleteLegalService(id: string): Promise<void> {
    await db.delete(legalServices).where(eq(legalServices.id, id));
  }

  // Lawyer operations
  async getAllLawyers(): Promise<Lawyer[]> {
    return await db
      .select()
      .from(lawyers)
      .orderBy(desc(lawyers.rating), desc(lawyers.successRate));
  }

  async getLawyer(id: string): Promise<Lawyer | undefined> {
    const [lawyer] = await db
      .select()
      .from(lawyers)
      .where(eq(lawyers.id, id));
    return lawyer;
  }

  async getAvailableLawyers(specialty?: string): Promise<Lawyer[]> {
    const query = db
      .select()
      .from(lawyers)
      .where(eq(lawyers.availability, 'available'));
    
    if (specialty) {
      return (await query).filter(l => l.specialties?.includes(specialty));
    }
    
    return await query;
  }

  async createLawyer(lawyerData: InsertLawyer): Promise<Lawyer> {
    const [lawyer] = await db.insert(lawyers).values(lawyerData).returning();
    return lawyer;
  }

  async updateLawyer(id: string, updates: Partial<InsertLawyer>): Promise<Lawyer> {
    const [lawyer] = await db
      .update(lawyers)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(lawyers.id, id))
      .returning();
    return lawyer;
  }

  async deleteLawyer(id: string): Promise<void> {
    await db.delete(lawyers).where(eq(lawyers.id, id));
  }

  // Message operations
  async getMessagesByUser(userId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(or(eq(messages.senderId, userId), eq(messages.receiverId, userId)))
      .orderBy(desc(messages.createdAt));
  }

  async getConversation(userId1: string, userId2: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        or(
          and(eq(messages.senderId, userId1), eq(messages.receiverId, userId2)),
          and(eq(messages.senderId, userId2), eq(messages.receiverId, userId1))
        )
      )
      .orderBy(asc(messages.createdAt));
  }

  async getUnreadMessagesCount(userId: string): Promise<number> {
    const result = await db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.receiverId, userId),
          eq(messages.isRead, false)
        )
      );
    return result.length;
  }

  async createMessage(messageData: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(messageData).returning();
    return message;
  }

  async markMessageAsRead(id: string): Promise<Message> {
    const [message] = await db
      .update(messages)
      .set({ isRead: true, readAt: new Date() })
      .where(eq(messages.id, id))
      .returning();
    return message;
  }

  async getDriversByCompany(companyId: string): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(
        and(
          eq(users.companyId, companyId),
          eq(users.userType, 'driver')
        )
      )
      .orderBy(asc(users.firstName));
  }

  // Route operations
  async getAllRoutes(): Promise<Route[]> {
    return await db
      .select()
      .from(routes)
      .where(eq(routes.isPublic, true))
      .orderBy(desc(routes.createdAt));
  }

  async getRoutesByType(routeType: 'tourist' | 'business' | 'recommended'): Promise<Route[]> {
    return await db
      .select()
      .from(routes)
      .where(
        and(
          eq(routes.routeType, routeType),
          eq(routes.isPublic, true)
        )
      )
      .orderBy(desc(routes.createdAt));
  }

  async getCompanyRoutes(companyId: string): Promise<Route[]> {
    return await db
      .select()
      .from(routes)
      .where(eq(routes.companyId, companyId))
      .orderBy(desc(routes.createdAt));
  }

  async getRouteById(id: string): Promise<Route | undefined> {
    const [route] = await db.select().from(routes).where(eq(routes.id, id));
    return route;
  }

  async createRoute(routeData: InsertRoute): Promise<Route> {
    const [route] = await db.insert(routes).values(routeData).returning();
    return route;
  }

  async updateRoute(id: string, updates: Partial<InsertRoute>): Promise<Route> {
    const [route] = await db
      .update(routes)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(routes.id, id))
      .returning();
    return route;
  }

  async deleteRoute(id: string): Promise<void> {
    await db.delete(routes).where(eq(routes.id, id));
  }

  // Whitelist operations
  async getAllWhitelist(): Promise<Whitelist[]> {
    return await db
      .select()
      .from(whitelist)
      .orderBy(desc(whitelist.createdAt));
  }

  async getWhitelistByPhone(phone: string): Promise<Whitelist | undefined> {
    const [entry] = await db
      .select()
      .from(whitelist)
      .where(eq(whitelist.phone, phone));
    return entry;
  }

  async checkWhitelistAccess(phone: string): Promise<boolean> {
    const entry = await this.getWhitelistByPhone(phone);
    return entry !== undefined && entry.isActive === true;
  }

  async addWhitelist(whitelistData: InsertWhitelist): Promise<Whitelist> {
    const [entry] = await db
      .insert(whitelist)
      .values(whitelistData)
      .returning();
    return entry;
  }

  async updateWhitelist(id: string, updates: Partial<InsertWhitelist>): Promise<Whitelist> {
    const [entry] = await db
      .update(whitelist)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(whitelist.id, id))
      .returning();
    return entry;
  }

  async deleteWhitelist(id: string): Promise<void> {
    await db.delete(whitelist).where(eq(whitelist.id, id));
  }

  async toggleWhitelist(id: string, isActive: boolean): Promise<Whitelist> {
    const [entry] = await db
      .update(whitelist)
      .set({ isActive, updatedAt: new Date() })
      .where(eq(whitelist.id, id))
      .returning();
    return entry;
  }
}

export const storage = new DatabaseStorage();
