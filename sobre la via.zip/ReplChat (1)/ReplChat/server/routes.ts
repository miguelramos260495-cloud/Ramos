import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  insertVehicleSchema,
  insertEmergencyContactSchema,
  insertTripSchema,
  insertAlertSchema,
  insertReportSchema,
  insertPlaceSchema,
  insertTripEventSchema,
  insertMaintenanceReminderSchema,
  insertVehicleStatusSchema,
  insertInsurancePolicySchema,
  insertTrafficBlockSchema,
  insertAutomaticAlertSchema,
  insertLegalServiceSchema,
  insertLawyerSchema,
  insertMessageSchema,
} from "@shared/schema";

// Twilio configuration
let twilioClient: any = null;

async function initTwilio() {
  try {
    if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
      // Validate Twilio credentials format
      if (!process.env.TWILIO_ACCOUNT_SID.startsWith('AC')) {
        console.log('⏳ Twilio ACCOUNT_SID debe empezar con "AC" - SMS deshabilitado');
        return;
      }
      
      const twilio = (await import('twilio')).default;
      twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
      console.log('✅ Twilio SMS configurado correctamente');
    } else {
      console.log('⏳ Credenciales Twilio no encontradas - SMS deshabilitado');
    }
  } catch (error: any) {
    console.log('⏳ Error Twilio:', error.message, '- SMS deshabilitado');
  }
}

initTwilio();

// Middleware para verificar acceso privado (solo admin)
const ADMIN_EMAIL = "miguelramos260495@gmail.com";

const isAdminOnly = async (req: any, res: any, next: any) => {
  try {
    const userId = req.user.claims.sub;
    const user = await storage.getUser(userId);
    
    if (user?.email !== ADMIN_EMAIL) {
      return res.status(403).json({ 
        message: "Acceso denegado. Esta aplicación es privada y solo está disponible para usuarios autorizados." 
      });
    }
    
    next();
  } catch (error) {
    console.error("Error en verificación de acceso:", error);
    res.status(500).json({ message: "Error al verificar acceso" });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Vehicle routes
  app.get("/api/vehicles", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const vehicles = await storage.getVehiclesByUser(userId);
      res.json(vehicles);
    } catch (error) {
      console.error("Error fetching vehicles:", error);
      res.status(500).json({ message: "Failed to fetch vehicles" });
    }
  });

  app.post("/api/vehicles", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const vehicleData = insertVehicleSchema.parse({
        ...req.body,
        userId,
      });
      const vehicle = await storage.createVehicle(vehicleData);
      res.status(201).json(vehicle);
    } catch (error: any) {
      console.error("Error creating vehicle:", error);
      res.status(400).json({ message: error.message || "Failed to create vehicle" });
    }
  });

  // Emergency contacts routes
  app.get("/api/emergency-contacts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const contacts = await storage.getEmergencyContacts(userId);
      res.json(contacts);
    } catch (error) {
      console.error("Error fetching contacts:", error);
      res.status(500).json({ message: "Failed to fetch contacts" });
    }
  });

  app.post("/api/emergency-contacts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const contactData = insertEmergencyContactSchema.parse({
        ...req.body,
        userId,
      });
      const contact = await storage.createEmergencyContact(contactData);
      res.status(201).json(contact);
    } catch (error: any) {
      console.error("Error creating contact:", error);
      res.status(400).json({ message: error.message || "Failed to create contact" });
    }
  });

  // Trip routes
  app.get("/api/trips", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const trips = await storage.getTripsByUser(userId);
      res.json(trips);
    } catch (error) {
      console.error("Error fetching trips:", error);
      res.status(500).json({ message: "Failed to fetch trips" });
    }
  });

  app.post("/api/trips", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tripData = insertTripSchema.parse({
        ...req.body,
        userId,
      });
      const trip = await storage.createTrip(tripData);
      res.status(201).json(trip);
    } catch (error: any) {
      console.error("Error creating trip:", error);
      res.status(400).json({ message: error.message || "Failed to create trip" });
    }
  });

  app.patch("/api/trips/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const trip = await storage.updateTrip(id, req.body);
      res.json(trip);
    } catch (error: any) {
      console.error("Error updating trip:", error);
      res.status(400).json({ message: error.message || "Failed to update trip" });
    }
  });

  // Alert routes
  app.get("/api/alerts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const alerts = await storage.getAlertsByUser(userId);
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  app.post("/api/alerts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const alertData = insertAlertSchema.parse({
        ...req.body,
        userId,
      });
      const alert = await storage.createAlert(alertData);

      // Send SMS notifications to emergency contacts
      const contacts = await storage.getEmergencyContacts(userId);
      const user = await storage.getUser(userId);
      
      if (twilioClient && process.env.TWILIO_PHONE_NUMBER) {
        const alertMessages: Record<string, string> = {
          robbery: `ALERTA DE EMERGENCIA: ${user?.firstName || 'Usuario'} reporta posible robo. Ubicación: ${alert.location}`,
          legal: `ASISTENCIA LEGAL: ${user?.firstName || 'Usuario'} requiere ayuda legal. Ubicación: ${alert.location}`,
          medical: `EMERGENCIA MÉDICA: ${user?.firstName || 'Usuario'} necesita asistencia médica. Ubicación: ${alert.location}`,
          safe_travel: `VIAJE SEGURO: ${user?.firstName || 'Usuario'} compartiendo ubicación en tiempo real. Ubicación: ${alert.location}`,
        };

        const message = alertMessages[alert.type] || `Alerta de ${user?.firstName || 'Usuario'}`;

        for (const contact of contacts) {
          try {
            await twilioClient.messages.create({
              body: message,
              from: process.env.TWILIO_PHONE_NUMBER,
              to: contact.phone,
            });
          } catch (smsError) {
            console.error(`Failed to send SMS to ${contact.phone}:`, smsError);
          }
        }
      }

      // Broadcast alert via WebSocket
      broadcastAlert(alert);

      res.status(201).json(alert);
    } catch (error: any) {
      console.error("Error creating alert:", error);
      res.status(400).json({ message: error.message || "Failed to create alert" });
    }
  });

  app.patch("/api/alerts/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const alert = await storage.updateAlert(id, req.body);
      broadcastAlert(alert);
      res.json(alert);
    } catch (error: any) {
      console.error("Error updating alert:", error);
      res.status(400).json({ message: error.message || "Failed to update alert" });
    }
  });

  // Report routes
  app.get("/api/reports", isAuthenticated, async (req: any, res) => {
    try {
      const reports = await storage.getActiveReports();
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });

  app.post("/api/reports", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reportData = insertReportSchema.parse({
        ...req.body,
        userId,
      });
      const report = await storage.createReport(reportData);
      
      // Award points for creating report
      const user = await storage.getUser(userId);
      if (user) {
        const newPoints = (user.rewardPoints || 0) + 10; // 10 points per report
        const newReportCount = (user.reportCount || 0) + 1;
        
        // Determine reward level based on points
        let rewardLevel = 'bronze';
        if (newPoints >= 1000) rewardLevel = 'platinum';
        else if (newPoints >= 500) rewardLevel = 'gold';
        else if (newPoints >= 200) rewardLevel = 'silver';
        
        await storage.updateUser(userId, {
          rewardPoints: newPoints,
          reportCount: newReportCount,
          rewardLevel,
        });
      }
      
      broadcastReport(report);
      res.status(201).json(report);
    } catch (error: any) {
      console.error("Error creating report:", error);
      res.status(400).json({ message: error.message || "Failed to create report" });
    }
  });

  // Place routes
  app.get("/api/places", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Get places based on user's company association
      // If user is associated with a company, they see public places + company places
      const places = await storage.getPlacesByCompany(user?.companyId || null);
      res.json(places);
    } catch (error) {
      console.error("Error fetching places:", error);
      res.status(500).json({ message: "Failed to fetch places" });
    }
  });

  app.post("/api/places", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const placeData = insertPlaceSchema.parse({
        ...req.body,
        createdBy: userId,
        // If user is part of a company (or IS a company), associate place with company
        companyId: user?.companyId || (user?.userType === 'company' ? userId : null),
      });
      const place = await storage.createPlace(placeData);
      res.status(201).json(place);
    } catch (error: any) {
      console.error("Error creating place:", error);
      res.status(400).json({ message: error.message || "Failed to create place" });
    }
  });

  app.patch("/api/places/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const place = await storage.updatePlace(id, req.body);
      res.json(place);
    } catch (error: any) {
      console.error("Error updating place:", error);
      res.status(400).json({ message: error.message || "Failed to update place" });
    }
  });

  // Trip events routes
  app.get("/api/trips/:tripId/events", isAuthenticated, async (req: any, res) => {
    try {
      const { tripId } = req.params;
      const events = await storage.getTripEvents(tripId);
      res.json(events);
    } catch (error) {
      console.error("Error fetching trip events:", error);
      res.status(500).json({ message: "Failed to fetch trip events" });
    }
  });

  app.post("/api/trips/:tripId/events", isAuthenticated, async (req: any, res) => {
    try {
      const { tripId } = req.params;
      const eventData = insertTripEventSchema.parse({
        ...req.body,
        tripId,
      });
      const event = await storage.createTripEvent(eventData);
      res.status(201).json(event);
    } catch (error: any) {
      console.error("Error creating trip event:", error);
      res.status(400).json({ message: error.message || "Failed to create trip event" });
    }
  });

  // Maintenance reminder routes
  app.get("/api/maintenance-reminders", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reminders = await storage.getMaintenanceReminders(userId);
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching maintenance reminders:", error);
      res.status(500).json({ message: "Failed to fetch maintenance reminders" });
    }
  });

  app.post("/api/maintenance-reminders", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reminderData = insertMaintenanceReminderSchema.parse({
        ...req.body,
        userId,
      });
      const reminder = await storage.createMaintenanceReminder(reminderData);
      res.status(201).json(reminder);
    } catch (error: any) {
      console.error("Error creating maintenance reminder:", error);
      res.status(400).json({ message: error.message || "Failed to create maintenance reminder" });
    }
  });

  app.patch("/api/maintenance-reminders/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const reminder = await storage.updateMaintenanceReminder(id, req.body);
      res.json(reminder);
    } catch (error: any) {
      console.error("Error updating maintenance reminder:", error);
      res.status(400).json({ message: error.message || "Failed to update maintenance reminder" });
    }
  });

  app.delete("/api/maintenance-reminders/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify ownership before deleting
      const reminders = await storage.getMaintenanceReminders(userId);
      const reminder = reminders.find(r => r.id === id);
      
      if (!reminder) {
        return res.status(404).json({ message: "Maintenance reminder not found or unauthorized" });
      }
      
      await storage.deleteMaintenanceReminder(id);
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting maintenance reminder:", error);
      res.status(400).json({ message: error.message || "Failed to delete maintenance reminder" });
    }
  });

  app.get("/api/maintenance-reminders/overdue", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reminders = await storage.getOverdueReminders(userId);
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching overdue reminders:", error);
      res.status(500).json({ message: "Failed to fetch overdue reminders" });
    }
  });

  app.get("/api/vehicles/:vehicleId/maintenance-reminders", isAuthenticated, async (req: any, res) => {
    try {
      const { vehicleId } = req.params;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Verify user owns this vehicle or is from the same company
      const vehicles = user?.userType === 'company' 
        ? await storage.getVehiclesByCompany(user.companyId || user.id)
        : await storage.getVehiclesByUser(userId);
      
      const hasAccess = vehicles.some(v => v.id === vehicleId);
      if (!hasAccess) {
        return res.status(403).json({ message: "Unauthorized to access this vehicle's maintenance reminders" });
      }
      
      const reminders = await storage.getMaintenanceRemindersByVehicle(vehicleId);
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching vehicle maintenance reminders:", error);
      res.status(500).json({ message: "Failed to fetch vehicle maintenance reminders" });
    }
  });

  // Insurance policy routes
  app.get("/api/insurance-policies", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const policies = await storage.getUserInsurances(userId);
      res.json(policies);
    } catch (error) {
      console.error("Error fetching insurance policies:", error);
      res.status(500).json({ message: "Failed to fetch insurance policies" });
    }
  });

  app.get("/api/insurance-policies/expiring", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const days = parseInt(req.query.days as string) || 30;
      
      let policies;
      if (user?.userType === 'company') {
        // For companies, get expiring policies from company's fleet
        const allCompanyPolicies = await storage.getCompanyInsurances(user.companyId || user.id);
        const futureDate = new Date();
        futureDate.setDate(futureDate.getDate() + days);
        
        policies = allCompanyPolicies.filter(p => 
          p.status === 'active' && new Date(p.endDate) <= futureDate
        ).sort((a, b) => new Date(a.endDate).getTime() - new Date(b.endDate).getTime());
      } else {
        policies = await storage.getExpiringInsurances(userId, days);
      }
      
      res.json(policies);
    } catch (error) {
      console.error("Error fetching expiring insurance policies:", error);
      res.status(500).json({ message: "Failed to fetch expiring insurance policies" });
    }
  });

  app.get("/api/company/insurance-policies", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user || user.userType !== 'company') {
        return res.status(403).json({ message: "Unauthorized: Only company users can access this" });
      }
      
      const policies = await storage.getCompanyInsurances(user.companyId || user.id);
      res.json(policies);
    } catch (error) {
      console.error("Error fetching company insurance policies:", error);
      res.status(500).json({ message: "Failed to fetch company insurance policies" });
    }
  });

  app.post("/api/insurance-policies", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const policyData = insertInsurancePolicySchema.parse({
        ...req.body,
        userId,
        companyId: user?.userType === 'company' ? (user.companyId || user.id) : null,
      });
      
      const policy = await storage.createInsurancePolicy(policyData);
      res.status(201).json(policy);
    } catch (error: any) {
      console.error("Error creating insurance policy:", error);
      res.status(400).json({ message: error.message || "Failed to create insurance policy" });
    }
  });

  app.patch("/api/insurance-policies/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Fetch the policy to verify ownership
      const userPolicies = await storage.getUserInsurances(userId);
      let policy = userPolicies.find(p => p.id === id);
      
      // If not found and user is company, check company policies
      if (!policy && user?.userType === 'company') {
        const companyPolicies = await storage.getCompanyInsurances(user.companyId || user.id);
        policy = companyPolicies.find(p => p.id === id);
      }
      
      if (!policy) {
        return res.status(404).json({ message: "Insurance policy not found or unauthorized" });
      }
      
      // Validate and whitelist safe fields only
      const updateSchema = insertInsurancePolicySchema.pick({
        insuranceCompany: true,
        policyNumber: true,
        phoneNumber: true,
        emergencyPhone: true,
        coverageType: true,
        coverageAmount: true,
        startDate: true,
        endDate: true,
        status: true,
        notes: true,
      }).partial();
      
      const validatedUpdates = updateSchema.parse(req.body);
      const updatedPolicy = await storage.updateInsurancePolicy(id, validatedUpdates);
      res.json(updatedPolicy);
    } catch (error: any) {
      console.error("Error updating insurance policy:", error);
      res.status(400).json({ message: error.message || "Failed to update insurance policy" });
    }
  });

  app.delete("/api/insurance-policies/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Fetch the policy to verify ownership
      const userPolicies = await storage.getUserInsurances(userId);
      let policy = userPolicies.find(p => p.id === id);
      
      // If not found and user is company, check company policies
      if (!policy && user?.userType === 'company') {
        const companyPolicies = await storage.getCompanyInsurances(user.companyId || user.id);
        policy = companyPolicies.find(p => p.id === id);
      }
      
      if (!policy) {
        return res.status(404).json({ message: "Insurance policy not found or unauthorized" });
      }
      
      await storage.deleteInsurancePolicy(id);
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting insurance policy:", error);
      res.status(400).json({ message: error.message || "Failed to delete insurance policy" });
    }
  });

  // Legal Services routes
  app.get("/api/legal-services", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const services = await storage.getUserLegalServices(userId);
      res.json(services);
    } catch (error) {
      console.error("Error fetching legal services:", error);
      res.status(500).json({ message: "Failed to fetch legal services" });
    }
  });

  app.get("/api/legal-services/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const service = await storage.getLegalService(id);
      if (!service) {
        return res.status(404).json({ message: "Legal service not found" });
      }
      res.json(service);
    } catch (error) {
      console.error("Error fetching legal service:", error);
      res.status(500).json({ message: "Failed to fetch legal service" });
    }
  });

  app.post("/api/legal-services", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const serviceData = insertLegalServiceSchema.parse({
        ...req.body,
        userId,
      });
      const service = await storage.createLegalService(serviceData);
      res.status(201).json(service);
    } catch (error: any) {
      console.error("Error creating legal service:", error);
      res.status(400).json({ message: error.message || "Failed to create legal service" });
    }
  });

  app.patch("/api/legal-services/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const service = await storage.updateLegalService(id, req.body);
      res.json(service);
    } catch (error: any) {
      console.error("Error updating legal service:", error);
      res.status(400).json({ message: error.message || "Failed to update legal service" });
    }
  });

  app.delete("/api/legal-services/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteLegalService(id);
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting legal service:", error);
      res.status(400).json({ message: error.message || "Failed to delete legal service" });
    }
  });

  // Lawyers routes
  app.get("/api/lawyers", isAuthenticated, async (req: any, res) => {
    try {
      const { specialty } = req.query;
      const lawyers = specialty 
        ? await storage.getAvailableLawyers(specialty as string)
        : await storage.getAllLawyers();
      res.json(lawyers);
    } catch (error) {
      console.error("Error fetching lawyers:", error);
      res.status(500).json({ message: "Failed to fetch lawyers" });
    }
  });

  app.get("/api/lawyers/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const lawyer = await storage.getLawyer(id);
      if (!lawyer) {
        return res.status(404).json({ message: "Lawyer not found" });
      }
      res.json(lawyer);
    } catch (error) {
      console.error("Error fetching lawyer:", error);
      res.status(500).json({ message: "Failed to fetch lawyer" });
    }
  });

  app.post("/api/lawyers", isAuthenticated, async (req: any, res) => {
    try {
      const lawyerData = insertLawyerSchema.parse(req.body);
      const lawyer = await storage.createLawyer(lawyerData);
      res.status(201).json(lawyer);
    } catch (error: any) {
      console.error("Error creating lawyer:", error);
      res.status(400).json({ message: error.message || "Failed to create lawyer" });
    }
  });

  app.patch("/api/lawyers/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const lawyer = await storage.updateLawyer(id, req.body);
      res.json(lawyer);
    } catch (error: any) {
      console.error("Error updating lawyer:", error);
      res.status(400).json({ message: error.message || "Failed to update lawyer" });
    }
  });

  app.delete("/api/lawyers/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteLawyer(id);
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting lawyer:", error);
      res.status(400).json({ message: error.message || "Failed to delete lawyer" });
    }
  });

  // Message routes (mensajería empresa-chofer)
  app.get("/api/messages", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messages = await storage.getMessagesByUser(userId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.get("/api/messages/conversation/:otherUserId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { otherUserId } = req.params;
      const conversation = await storage.getConversation(userId, otherUserId);
      res.json(conversation);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  app.get("/api/messages/unread-count", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const count = await storage.getUnreadMessagesCount(userId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread count:", error);
      res.status(500).json({ message: "Failed to fetch unread count" });
    }
  });

  app.post("/api/messages", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messageData = insertMessageSchema.parse({
        ...req.body,
        senderId: userId,
      });
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error: any) {
      console.error("Error creating message:", error);
      res.status(400).json({ message: error.message || "Failed to create message" });
    }
  });

  app.patch("/api/messages/:id/read", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const message = await storage.markMessageAsRead(id);
      res.json(message);
    } catch (error: any) {
      console.error("Error marking message as read:", error);
      res.status(400).json({ message: error.message || "Failed to mark message as read" });
    }
  });

  // Company driver routes
  app.get("/api/company/drivers", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user || user.userType !== 'company') {
        return res.status(403).json({ message: "Unauthorized: Only company users can access this" });
      }
      
      const drivers = await storage.getDriversByCompany(user.id);
      res.json(drivers);
    } catch (error) {
      console.error("Error fetching company drivers:", error);
      res.status(500).json({ message: "Failed to fetch drivers" });
    }
  });

  app.get("/api/company/trips", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user || user.userType !== 'company') {
        return res.status(403).json({ message: "Unauthorized: Only company users can access this" });
      }
      
      const trips = await storage.getTripsByCompany(user.id);
      res.json(trips);
    } catch (error) {
      console.error("Error fetching company trips:", error);
      res.status(500).json({ message: "Failed to fetch company trips" });
    }
  });

  // Route cost calculation
  app.post("/api/routes/calculate-costs", isAuthenticated, async (req: any, res) => {
    try {
      const { distance, vehicleType, fuelEfficiency } = req.body;
      
      // Validate input
      if (!distance || distance <= 0) {
        return res.status(400).json({ message: "Invalid distance" });
      }
      
      // Cálculo de combustible (precio promedio diesel/gasolina en México)
      const fuelPrice = vehicleType === 'truck' || vehicleType === 'bus' ? 24.5 : 23.0; // MXN por litro
      const efficiency = fuelEfficiency || (vehicleType === 'truck' ? 6 : vehicleType === 'bus' ? 8 : 12); // km/l
      const fuelCost = (distance / efficiency) * fuelPrice;
      
      // Estimación de casetas (promedio ~$2.5 MXN/km en autopistas federales)
      const tollCost = distance * 2.5;
      
      // Cálculo de paradas de descanso recomendadas (cada 300 km completos)
      const restStops = Math.floor(distance / 300);
      
      res.json({
        distance,
        estimatedFuelCost: Math.round(fuelCost),
        estimatedTollCost: Math.round(tollCost),
        totalEstimatedCost: Math.round(fuelCost + tollCost),
        recommendedRestStops: restStops,
        breakdown: {
          fuelLiters: Math.round(distance / efficiency),
          fuelPricePerLiter: fuelPrice,
          fuelEfficiency: efficiency,
        }
      });
    } catch (error: any) {
      console.error("Error calculating route costs:", error);
      res.status(400).json({ message: error.message || "Failed to calculate route costs" });
    }
  });

  // Weight validation
  app.post("/api/vehicles/check-weight", isAuthenticated, async (req: any, res) => {
    try {
      const { vehicleType, currentWeight } = req.body;
      
      // Validate input
      if (!vehicleType || currentWeight === undefined || currentWeight < 0) {
        return res.status(400).json({ message: "Invalid vehicle type or weight" });
      }
      
      // Límites de peso según NOM-012-SCT-2 (toneladas)
      const weightLimits: any = {
        truck: 48.5, // Tracto-remolque estándar
        bus: 18.5,
        van: 3.5,
        car: 2.0,
        motorcycle: 0.5,
      };
      
      const limit = weightLimits[vehicleType] || 3.5;
      const isOverweight = currentWeight > limit;
      const percentageUsed = (currentWeight / limit) * 100;
      
      // Correct warning logic: check overweight first
      let warning = 'Peso normal';
      if (isOverweight) {
        warning = '¡Sobrepeso!';
      } else if (percentageUsed > 90) {
        warning = 'Cerca del límite';
      }
      
      res.json({
        vehicleType,
        currentWeight,
        weightLimit: limit,
        isOverweight,
        percentageUsed: Math.round(percentageUsed),
        excessWeight: isOverweight ? Math.round((currentWeight - limit) * 10) / 10 : 0,
        warning,
      });
    } catch (error: any) {
      console.error("Error checking weight:", error);
      res.status(400).json({ message: error.message || "Failed to check weight" });
    }
  });

  // Route endpoints
  app.get("/api/routes", async (req, res) => {
    try {
      const { type } = req.query;
      let routes;
      
      if (type && (type === 'tourist' || type === 'business' || type === 'recommended')) {
        routes = await storage.getRoutesByType(type as any);
      } else {
        routes = await storage.getAllRoutes();
      }
      
      res.json(routes);
    } catch (error) {
      console.error("Error fetching routes:", error);
      res.status(500).json({ message: "Failed to fetch routes" });
    }
  });

  app.get("/api/routes/:id", async (req, res) => {
    try {
      const route = await storage.getRouteById(req.params.id);
      if (!route) {
        return res.status(404).json({ message: "Route not found" });
      }
      res.json(route);
    } catch (error) {
      console.error("Error fetching route:", error);
      res.status(500).json({ message: "Failed to fetch route" });
    }
  });

  app.get("/api/company/routes", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user || user.userType !== 'company') {
        return res.status(403).json({ message: "Unauthorized: Only company users can access this" });
      }
      
      const routes = await storage.getCompanyRoutes(user.id);
      res.json(routes);
    } catch (error) {
      console.error("Error fetching company routes:", error);
      res.status(500).json({ message: "Failed to fetch company routes" });
    }
  });

  app.get("/api/company/vehicles", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user || user.userType !== 'company') {
        return res.status(403).json({ message: "Unauthorized: Only company users can access this" });
      }
      
      const vehicles = await storage.getVehiclesByCompany(user.companyId || user.id);
      res.json(vehicles);
    } catch (error) {
      console.error("Error fetching company vehicles:", error);
      res.status(500).json({ message: "Failed to fetch company vehicles" });
    }
  });

  app.post("/api/routes", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const routeData = {
        ...req.body,
        createdBy: user.id,
        companyId: user.userType === 'company' ? user.id : null,
      };

      const route = await storage.createRoute(routeData);
      res.json(route);
    } catch (error) {
      console.error("Error creating route:", error);
      res.status(500).json({ message: "Failed to create route" });
    }
  });

  app.patch("/api/routes/:id", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      const route = await storage.getRouteById(req.params.id);
      
      if (!route) {
        return res.status(404).json({ message: "Route not found" });
      }
      
      if (route.createdBy !== user?.id) {
        return res.status(403).json({ message: "Unauthorized to update this route" });
      }

      const updatedRoute = await storage.updateRoute(req.params.id, req.body);
      res.json(updatedRoute);
    } catch (error) {
      console.error("Error updating route:", error);
      res.status(500).json({ message: "Failed to update route" });
    }
  });

  app.delete("/api/routes/:id", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      const route = await storage.getRouteById(req.params.id);
      
      if (!route) {
        return res.status(404).json({ message: "Route not found" });
      }
      
      if (route.createdBy !== user?.id) {
        return res.status(403).json({ message: "Unauthorized to delete this route" });
      }

      await storage.deleteRoute(req.params.id);
      res.json({ message: "Route deleted successfully" });
    } catch (error) {
      console.error("Error deleting route:", error);
      res.status(500).json({ message: "Failed to delete route" });
    }
  });

  // Whitelist routes (admin only)
  const isAdmin = async (req: any, res: any, next: any) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.email === "miguelramos260495@gmail.com") {
        next();
      } else {
        res.status(403).json({ message: "Acceso denegado - Solo administradores" });
      }
    } catch (error) {
      res.status(401).json({ message: "No autorizado" });
    }
  };

  app.get("/api/whitelist", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const entries = await storage.getAllWhitelist();
      res.json(entries);
    } catch (error) {
      console.error("Error fetching whitelist:", error);
      res.status(500).json({ message: "Error al obtener lista blanca" });
    }
  });

  app.post("/api/whitelist", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      const { insertWhitelistSchema } = await import("@shared/schema");
      
      const whitelistData = insertWhitelistSchema.parse({
        ...req.body,
        addedBy: user?.email || "",
      });
      
      const entry = await storage.addWhitelist(whitelistData);
      res.status(201).json(entry);
    } catch (error: any) {
      console.error("Error adding whitelist:", error);
      if (error.message?.includes('unique constraint')) {
        res.status(400).json({ message: "Este número ya está en la lista" });
      } else if (error.name === 'ZodError') {
        res.status(400).json({ message: "Datos inválidos", errors: error.errors });
      } else {
        res.status(400).json({ message: error.message || "Error al agregar a lista blanca" });
      }
    }
  });

  app.patch("/api/whitelist/:id", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const { insertWhitelistSchema } = await import("@shared/schema");
      const whitelistData = insertWhitelistSchema.partial().parse(req.body);
      
      const entry = await storage.updateWhitelist(req.params.id, whitelistData);
      res.json(entry);
    } catch (error: any) {
      console.error("Error updating whitelist:", error);
      if (error.name === 'ZodError') {
        res.status(400).json({ message: "Datos inválidos", errors: error.errors });
      } else {
        res.status(400).json({ message: error.message || "Error al actualizar lista blanca" });
      }
    }
  });

  app.delete("/api/whitelist/:id", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      await storage.deleteWhitelist(req.params.id);
      res.json({ message: "Entrada eliminada de lista blanca" });
    } catch (error) {
      console.error("Error deleting whitelist:", error);
      res.status(500).json({ message: "Error al eliminar de lista blanca" });
    }
  });

  app.post("/api/whitelist/:id/toggle", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const { z } = await import("zod");
      const toggleSchema = z.object({
        isActive: z.boolean(),
      });
      
      const { isActive } = toggleSchema.parse(req.body);
      const entry = await storage.toggleWhitelist(req.params.id, isActive);
      res.json(entry);
    } catch (error: any) {
      console.error("Error toggling whitelist:", error);
      if (error.name === 'ZodError') {
        res.status(400).json({ message: "Datos inválidos", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error al cambiar estado" });
      }
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const clients = new Set<WebSocket>();

  wss.on('connection', (ws: WebSocket) => {
    clients.add(ws);
    console.log('WebSocket client connected');

    ws.on('close', () => {
      clients.delete(ws);
      console.log('WebSocket client disconnected');
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });

  function broadcastAlert(alert: any) {
    const message = JSON.stringify({ type: 'alert', data: alert });
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  function broadcastReport(report: any) {
    const message = JSON.stringify({ type: 'report', data: report });
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  return httpServer;
}
